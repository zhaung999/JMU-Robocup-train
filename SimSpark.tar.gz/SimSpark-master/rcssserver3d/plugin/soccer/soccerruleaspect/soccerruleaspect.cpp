/* -*- mode: c++; c-basic-offset: 4; indent-tabs-mode: nil -*-

   this file is part of rcssserver3D
   Fri May 9 2003
   Copyright (C) 2002,2003 Koblenz University
   Copyright (C) 2003 RoboCup Soccer Server 3D Maintenance Group
   $Id$

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include "soccerruleaspect.h"
#include <salt/random.h>
#include <zeitgeist/logserver/logserver.h>
#include <oxygen/agentaspect/agentaspect.h>
#include <oxygen/physicsserver/rigidbody.h>
#include <oxygen/physicsserver/joint.h>
#include <oxygen/physicsserver/boxcollider.h>
#include <oxygen/sceneserver/scene.h>
#include <oxygen/gamecontrolserver/gamecontrolserver.h>
#include <oxygen/agentaspect/effector.h>
#include <soccerbase/soccerbase.h>
#include <gamestateaspect/gamestateaspect.h>
#include <ballstateaspect/ballstateaspect.h>
#include <agentstate/agentstate.h>
#include <algorithm>

#ifdef RVDRAW
#include <rvdraw/rvdraw.h>
#endif // RVDRAW

using namespace oxygen;
using namespace boost;
using namespace std;
using namespace salt;

SoccerRuleAspect::SoccerRuleAspect() :
    SoccerControlAspect(),
    mBallRadius(0.111),
    mAgentRadius(0.4),
    mGoalPauseTime(3),
    mKickInPauseTime(1),
    mHalfTime(2.25 * 60),
    mDropBallTime(20),
    mFreeKickDist(9.15),
    mFreeKickMoveDist(15.15),
    mRepelPlayersForKick(false),
    mKickRepelDist(0.5),
    mGoalKickDist(1.0),
    mAutomaticKickOff(false),
    mWaitBeforeKickOff(1.0),
    mSingleHalfTime(false),
    mAutomaticQuit(true),
    mChangeSidesInSecondHalf(true),
    mAutoKickOffTimeOrigin(1000000.0),
    mSayMsgSize(20),
    mAudioCutDist(50.0),
    mNotStandingMaxTime(1000),       // max time player may be sitted or laying down before being repositioned
    mGroundMaxTime(1000),            // max time player may be on the ground before being repositioned
    mGoalieNotStandingMaxTime(1000), // max time goalie may be sitted or laying down before being repositioned
    mGoalieGroundMaxTime(1000),      // max time goalie (pl number 1) may be on the ground before being repositioned
    mMinOppDistance(0),          // min dist for closest Opponent to ball in order to use repositions for 2nd, 3rd player
    mMin2PlDistance(0),            // min dist for second closest of team before being repositioned
    mMin3PlDistance(0),            // min dist for third closest of team before being repositioned
    mMaxPlayersInsideOwnArea(1000),  // maximum number of players of the defending team that may be inside own penalty area
    mIllegalDefenseBeamPenalty(false),
    mMaxTouchGroupSize(1000),
    mTouchingFoulBeamPenalty(false),
    mMaxFoulTime(0.0),              // maximum time allowed for a player to commit a positional foul before being repositioned
    mSelfCollisionsTolerance(0.0),     
    mPrintSelfCollisions(true),     
    mFoulOnSelfCollisions(false),
    mSelfCollisionJointFrozenTime(1.0),
    mSelfCollisionJointThawTime(2.0),  
    mSelfCollisionBeamPenalty(false),     
    mSelfCollisionBeamCooldownTime(10.0),
    mWriteSelfCollisionsToFile(false),
    mSelfCollisionRecordFilename("SelfCollisions.txt"),
    mFirstCollidingAgent(true),
    mNotOffside(false),
    mLastModeWasPlayOn(false),
    mUseOffside(true),
    mUseCharging(false),
    mChargingMinSpeed(0.2),
    mChargingMinBallSpeedAngle(15),
    mChargingMinDeltaDist(0.2),
    mChargingMinDeltaAng(30),
    mChargingImmunityTime(1),
    mChargingCollisionMinTime(0.2),
    mChargingMaxBallRulesDist(100),
    mChargingMinCollBallDist(0.1),
    mMinCollisionSpeed(0.15),
    mFoulHoldTime(0.5),
    mLastFreeKickKickTime(0),
    mCheckFreeKickKickerFoul(false),
    mAllowKickOffTeamToScore(true),
    mIndirectKick(false),
    mPenaltyShootout(false),
    mPenaltyShootoutBallDistance(6.0),
    mPenaltyShootoutBehindBallDistance(4.0),
    mPenaltyShootoutMaxTime(25.0),
    mPenaltyShootoutMinRounds(5),
    mPenaltyShootoutMaxRounds(10),
    mKeepaway(false),
    mKeepawayCenterX(0.0),
    mKeepawayCenterY(0.0),
    mKeepawayLength(20.0),
    mKeepawayWidth(20.0),
    mKeepawayLengthReductionRate(4.0),
    mKeepawayWidthReductionRate(4.0),
    mMaxNumSafeRepositionAttempts(100),
    mStartAnyFieldPosition(false),
    mPassModeMaxBallSpeed(0.05),
    mPassModeMaxBallDist(0.5),
    mPassModeMinOppBallDist(1.0),
    mPassModeDuration(4.0),
    mPassModeScoreWaitTime(10.0),
    mPassModeRetryWaitTime(3.0),
    mBallHoldRadius(0.12),
    mBallHoldMaxTime(5.0),
    mBallHoldGoalieMaxTime(10.0),
    mBallHoldResetTime(0.5),
    mBallHoldMaxDistance(1.0),
    mBallHoldOppDistance(0.75),
    mBallHoldBeamPenalty(false),
    mRng(random_device()())
{
    mFreeKickPos = Vector3f(0.0,0.0,mBallRadius);
    ResetFoulCounter(TI_LEFT);
    ResetFoulCounter(TI_RIGHT);

    ResetKickChecks();
      
#ifdef RVDRAW
    // Create connection for sending draw commands to roboviz
    mRVSender = std::shared_ptr<RVSender>(new RVSender());
    if (mRVSender->getSockFD() == -1)
    {
        mRVSender.reset();
    }
#endif // RVDRAW

    // Initialize values
    for (int i = 0; i <= 11; i++) 
    {
        for (int t = 0; t <= 2; t++) 
        {
            playerTimeSinceLastWasMoved[i][t] = 1/.02;
            for(int j = 0; j < AVERAGE_VELOCITY_MEASUREMENTS; j++)
            {
                playerVelocities[i][t][j] = salt::Vector3f(0,0,0);
            }

            playerTimeLastSelfCollision[i][t] = -1e5;   // large negative value
        }
    }
    mPenaltyShootoutCurrentKickerTeam = TI_NONE;
    mPenaltyShootoutBallPlaced = false;
}

SoccerRuleAspect::~SoccerRuleAspect()
{
}

void
SoccerRuleAspect::MoveBall(const Vector3f& pos)
{
    mBallBody->SetPosition(pos);
    mBallBody->SetVelocity(Vector3f(0,0,0));
    mBallBody->SetAngularVelocity(Vector3f(0,0,0));
    mBallBody->Enable();
    // Set the free kick position to where we have moved the ball so as to not
    // accidentally use an old ball position for the next free kick.
    mFreeKickPos = Vector3f(pos.x(), pos.y(), mBallRadius);
}

/* Uses only Ball and Players positions and detects overcrowind near ball and areas and
players inappropriate behavior (laying on the ground or not walking for too much time) */
void
SoccerRuleAspect::AutomaticSimpleReferee()
{
    if (mKeepaway)
    {
        TTime game_time = mGameState->GetTime();

        float areaMinX = mKeepawayCenterX - mKeepawayLength/2.0 + (mKeepawayLengthReductionRate/2.0*game_time/60.0);
        float areaMaxX = mKeepawayCenterX + mKeepawayLength/2.0 - (mKeepawayLengthReductionRate/2.0*game_time/60.0);
        float areaMinY = mKeepawayCenterY - mKeepawayWidth/2.0 + (mKeepawayWidthReductionRate/2.0*game_time/60.0);
        float areaMaxY = mKeepawayCenterY + mKeepawayWidth/2.0 - (mKeepawayWidthReductionRate/2.0*game_time/60.0);

#ifdef RVDRAW
        if (mRVSender) 
        {
            mRVSender->clear();
            mRVSender->drawLine("KeepawayArea", areaMinX, areaMinY, areaMinX, areaMaxY, RVSender::RED);
            mRVSender->drawLine("KeepawayArea", areaMinX, areaMaxY, areaMaxX, areaMaxY, RVSender::RED);
            mRVSender->drawLine("KeepawayArea", areaMaxX, areaMaxY, areaMaxX, areaMinY, RVSender::RED);
            mRVSender->drawLine("KeepawayArea", areaMaxX, areaMinY, areaMinX, areaMinY, RVSender::RED);
            mRVSender->refresh();
        }
#endif // RVDRAW

        if (game_time > 0)
        {
            bool fBallOutsideKeepawayBox = false;  
            Vector3f ball_pos = mBallBody->GetPosition();
            if (ball_pos.x() < areaMinX
                || ball_pos.x() > areaMaxX
                || ball_pos.y() < areaMinY
                || ball_pos.y() > areaMaxY)
            {
                fBallOutsideKeepawayBox = true;
            }   
        
            bool fBallCollidedWithTaker = mBallState->GetBallCollidingWithAgentTeam(TI_RIGHT);

            if (fBallOutsideKeepawayBox || fBallCollidedWithTaker)
            {
                mGameState->SetPlayMode(PM_GameOver);
            }
        }
    }

    // Reset counters and do not consider players' fouls when game is not
    // running (when players can beam)
    if (mGameState->IsPaused())
    {
        ResetFoulCounter(TI_LEFT);
        ResetFoulCounter(TI_RIGHT);
        UpdateSelfCollisions(true /*reset*/);
    }
    else
    {
        CalculateDistanceArrays(TI_LEFT);    	// Calculates distance arrays for left team
        CalculateDistanceArrays(TI_RIGHT);   	// Calculates distance arrays for right team
        UpdateTimesSinceLastBallTouch();        // Resets time since last ball touch for agents currently colliding with ball
        AnalyseBallHoldingFouls();              // Analyzes if there are any ball holding fouls
        AnalyseChargingFouls();                 // Analyzes if there are any charging fouls
        AnalyseSelfCollisionFouls(TI_LEFT);
        AnalyseSelfCollisionFouls(TI_RIGHT);
        AnalyseFouls(TI_LEFT);   		// Analyzes simple fouls for the left team
        AnalyseFouls(TI_RIGHT);   		// Analyzes simple fouls for the right team

        if (rand()%2 == 0) {
            AnalyseTouchGroups(TI_LEFT);            // Analyzes whether too many players are touching for the left team
            AnalyseTouchGroups(TI_RIGHT);           // Analyzes whether too many players are touching for the right team
        } else {
            AnalyseTouchGroups(TI_RIGHT);           // Analyzes whether too many players are touching for the right team
            AnalyseTouchGroups(TI_LEFT);            // Analyzes whether too many players are touching for the left team
        }

        if (rand()%2 == 0) {
            ClearPlayersAutomatic(TI_LEFT);   	// enforce standing and not overcrowding rules for left team
            ClearPlayersAutomatic(TI_RIGHT);  	// enforce standing and not overcrowding rules for right team
        } else {
            ClearPlayersAutomatic(TI_RIGHT);   	// enforce standing and not overcrowding rules for right team
            ClearPlayersAutomatic(TI_LEFT);  	// enforce standing and not overcrowding rules for left team
        }

        // Reset touch groups
        ResetTouchGroups(TI_LEFT);
        ResetTouchGroups(TI_RIGHT);

        UpdateSelfCollisions(false /*reset*/);

        // If in penalty shootout mode check that the goalie remains in the penalty area
        // Don't check if a goal has already been awarded in this cycle (the game state will change to "paused" in the next cycle)
        if (mPenaltyShootout && !mGoalAwarded) 
        {
            TTeamIndex activeGoalieTeam = SoccerBase::OpponentTeam(mPenaltyShootoutCurrentKickerTeam);
            if (activeGoalieTeam == TI_NONE)
                return;

            SoccerBase::TAgentStateList agent_states;
            if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, activeGoalieTeam))
                return;
            std::shared_ptr<oxygen::Transform> agent_aspect;
            SoccerBase::TAgentStateList::const_iterator i;
            for (i = agent_states.begin(); i != agent_states.end(); ++i)
            {
                if ((*i)->GetUniformNumber() != 1)
                {
                    // Don't penalize the kicker
                    continue;
                }
                SoccerBase::GetTransformParent(**i, agent_aspect);
                Vector3f agentPos = agent_aspect->GetWorldTransform().Pos();
                float xPos = agentPos.x();
                float yPos = agentPos.y();
                if (
                     (activeGoalieTeam == TI_RIGHT && (xPos < mRightPenaltyArea.minVec[0] || yPos < mRightPenaltyArea.minVec[1] || yPos > mRightPenaltyArea.maxVec[1]))
                    || (activeGoalieTeam == TI_LEFT && (xPos > mLeftPenaltyArea.maxVec[0] || yPos < mLeftPenaltyArea.minVec[1] || yPos > mLeftPenaltyArea.maxVec[1]))
                )
                {
                    // Penalty shootout goalie has left penalty area so award goal
                    mGameState->ScoreTeam(SoccerBase::OpponentTeam(activeGoalieTeam));
                    mGameState->SetPlayMode((activeGoalieTeam == TI_LEFT) ? PM_Goal_Right : PM_Goal_Left);
                    mGoalAwarded = true;
                }
            }
        }
    }
}


void
SoccerRuleAspect::ResetFoulCounterPlayer(int unum, TTeamIndex idx)
{
    playerGround[unum][idx] = 0;
    playerNotStanding[unum][idx] = 0;
    playerStanding[unum][idx] = 5/0.02;   // Considers player has been standing for some time in playoff
    prevPlayerInsideOwnArea[unum][idx] = 0;
    playerInsideOwnArea[unum][idx] = 0;
    playerFoulTime[unum][idx] = 0;
    playerTimeSinceStartBallHold[unum][idx] = 0;
    playerTimeSinceStopBallHold[unum][idx] = 0;
    playerTimeSinceLastBallTouch[unum][idx] = mChargingImmunityTime/0.02;
    playerChargingTime[unum][idx] = mChargingCollisionMinTime/0.02;
    playerLastFoul[unum][idx] = FT_None;
    
    playerSelfCollisions[unum][idx] = 0;
}

void
SoccerRuleAspect::ResetFoulCounter(TTeamIndex idx)
{
    for (int t = 1; t <= 11; t++)
    {
        ResetFoulCounterPlayer(t, idx);
    }
}

void
SoccerRuleAspect::UpdateSelfCollisions(bool reset)
{
    if (!mFoulOnSelfCollisions || mSelfCollisionBeamPenalty) {
        return;
    }

    std::shared_ptr<GameControlServer> game_control;
    if (!SoccerBase::GetGameControlServer(*this, game_control)) {
        return;
    }
            
    GameControlServer::TAgentAspectList agentAspects;
    game_control->GetAgentAspectList(agentAspects);
    GameControlServer::TAgentAspectList::iterator aaiter;
    for (
         aaiter = agentAspects.begin();
         aaiter != agentAspects.end();
         ++aaiter
         )
        {
            
            std::shared_ptr<AgentState> agentState =
                std::dynamic_pointer_cast<AgentState>((*aaiter)->GetChild("AgentState", true));

            if (!agentState) {
                continue;
            }

            int unum = agentState->GetUniformNumber();
            TTeamIndex idx = agentState->GetTeamIndex();
            std::shared_ptr<oxygen::AgentAspect> agent = std::static_pointer_cast<oxygen::AgentAspect>(*aaiter);

            for (std::map<std::string,TTime>::iterator it=lastTimeJointFrozen[unum][idx].begin(); it!=lastTimeJointFrozen[unum][idx].end(); ++it) {
                std::string jointName = it->first;
                TTime jointLastFrozenTime = it->second;
                if (jointLastFrozenTime >= 0 && (reset || mGameState->GetTime()-jointLastFrozenTime >= mSelfCollisionJointFrozenTime)) {
                    std::shared_ptr<oxygen::Effector> effector = std::dynamic_pointer_cast<oxygen::Effector>(agent->GetEffector(jointName));
                    if (effector) {
                        effector->Enable();
                    }
                }
                if (jointLastFrozenTime >= 0 && (reset || mGameState->GetTime()-jointLastFrozenTime >= mSelfCollisionJointFrozenTime+mSelfCollisionJointThawTime)) {
                    lastTimeJointFrozen[unum][idx][jointName] = -1000;
                }
            }
        }
}


// Resets time since last ball touch for agents currently colliding with ball
void 
SoccerRuleAspect::UpdateTimesSinceLastBallTouch()
{
    if (mBallState.get() == 0)
        return;

    list<std::shared_ptr<AgentAspect> > agents;
    if (mBallState->GetCollidingAgents(agents))
    {
        for (list<std::shared_ptr<AgentAspect> > ::const_iterator agentIt = agents.begin();
             agentIt != agents.end();
             agentIt++) 
        {
            std::shared_ptr<AgentState> agentState;
            if (!SoccerBase::GetAgentState(*agentIt, agentState))
            {
                GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                    "AgentState from an AgentAspect\n";
            }
            else
            {
                int unum = agentState->GetUniformNumber();
                int idx = agentState->GetTeamIndex();
                playerTimeSinceLastBallTouch[unum][idx] = 0;
            }
        }
    }   
}

// Process agent state: standing, sitted, laying down, ...
void
SoccerRuleAspect::ProcessAgentState(salt::Vector3f pos, int unum, TTeamIndex idx)
{
    float groundZVal = 0.15;  //below this player is on the ground
    float middleZVal = 0.25;  //above this player is standing (or trying...)

    //increase player not standing if it is not in upward position and inside of field
    if (pos.z() < middleZVal && fabs(pos.y())< mFieldWidth / 2 + 0.1)
    {
        playerNotStanding[unum][idx]++;
        playerStanding[unum][idx] = 0;  	//player not standing
    }

    //increase player near ground if it is very low and inside of field
    if (pos.z() < groundZVal && fabs(pos.y())< mFieldWidth / 2 + 0.1)
    {
        playerGround[unum][idx]++;
    }

    //increase player standing or at least trying... Reset ground
    if (pos.z() >= middleZVal)
    {
        playerStanding[unum][idx]++;
        playerGround[unum][idx] = 0;
    }

    //Player standing for some cycles (0.5 seconds) reset not standing count
    if (playerStanding[unum][idx] > 0.5 / 0.02) {
        playerNotStanding[unum][idx] = 0;
    }

    playerTimeSinceLastBallTouch[unum][idx]++;
    playerChargingTime[unum][idx]++;
    playerTimeSinceLastWasMoved[unum][idx]++;
}

// Calculates ordering on a distance vector
void SoccerRuleAspect::SimpleOrder(float dArr[][3], int oArr[][3], TTeamIndex idx)
{
    for(int t1 = 1; t1 <= 11; t1++) {
        if (HaveEnforceableFoul(t1,idx)) {
            // Don't count players who have committed a foul
            oArr[t1][idx] = -1;
            continue;
        }
        for(int t2 = t1 + 1; t2 <= 11; t2++) {
            if (HaveEnforceableFoul(t2,idx)) {
                // Don't count players who have committed a foul
                continue;
            }
            if (dArr[t1][idx] >= dArr[t2][idx])
                oArr[t1][idx]++;
            else
                oArr[t2][idx]++;
        }
    }
//    DEBUG
//    if (dArr[1][idx]<1000.0) {
//      cout << "Team: " << idx << "  --> ";
//      for(int t1=1; t1<=6; t1++)
//	if (dArr[t1][idx]<5.0) cout << t1 << " o:" << oArr[t1][idx] << " d: " << dArr[t1][idx] << "  | ";
//      cout << endl;
//    }
}

// Calculate Distance arrays and ordering to the ball and own goal
void SoccerRuleAspect::CalculateDistanceArrays(TTeamIndex idx)
{
    if (idx == TI_NONE || mBallState.get() == 0)
        return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    salt::Vector3f ballPos = mBallBody->GetPosition();
    salt::Vector3f ownGoalPos;
    if (idx == TI_LEFT)
        ownGoalPos = Vector3f(-mFieldLength/2.0, 0.0, 0.0);
    else
        ownGoalPos = Vector3f(mFieldLength/2.0, 0.0, 0.0);

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;

    numPlInsideOwnArea[idx] = 0;
    numPlReposInsideOwnArea[idx] = 0;
    closestPlayer[idx] = 1;
    closestPlayerDist[idx] = 1000.0;
    for(int t = 1; t <= 11; t++)
    {
        distArr[t][idx]=1000.0;
        ordArr[t][idx]=1;
        distGArr[t][idx]=1000.0;
        ordGArr[t][idx]=1;
    }

    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);
        Vector3f agentPos = agent_aspect->GetWorldTransform().Pos();

        int unum = (*i)->GetUniformNumber();
        distArr[unum][idx] = sqrt((agentPos.x()-ballPos.x())*(agentPos.x()-ballPos.x()) +
                                  (agentPos.y()-ballPos.y())*(agentPos.y()-ballPos.y()));
        distGArr[unum][idx] = sqrt((agentPos.x()-ownGoalPos.x())*(agentPos.x()-ownGoalPos.x()) +
                                   (agentPos.y()-ownGoalPos.y())*(agentPos.y()-ownGoalPos.y()));

        // determine closest player
        if (distArr[unum][idx] < closestPlayerDist[idx])
        {
            closestPlayerDist[idx] = distArr[unum][idx];
            closestPlayer[idx] = unum;
        }

        // save player inside area state in previous cycle
        prevPlayerInsideOwnArea[unum][idx] = playerInsideOwnArea[unum][idx];

        // determine number of players inside area and set inside area state of player
        if (((idx == TI_LEFT && mLeftPenaltyArea.Contains(Vector2f(agentPos.x(), agentPos.y()))) ||
             (idx == TI_RIGHT && mRightPenaltyArea.Contains(Vector2f(agentPos.x(), agentPos.y()))))
            && !HaveEnforceableFoul(unum,idx))
        {
            numPlInsideOwnArea[idx]++;
            playerInsideOwnArea[unum][idx] = 1;

            if (unum == 1)
            {
                //goalie is not repositioned when inside own area...
                distGArr[unum][idx] = 0.0;
            } else if (prevPlayerInsideOwnArea[unum][idx] == 0) {
                // Ignore players who just entered penalty area, only want to consider existing ones for repositioning when
                // goalie enters (players who just entered will be automatically repositioned if too many players in area) 
                distGArr[unum][idx] = 1000.0;
            }
        }
        else {
            playerInsideOwnArea[unum][idx] = 0;
            // Only keep and effectively rank distances for players inside own area
            distGArr[unum][idx] = 1000.0;
        }

        // Process agent state: standing, sitted, laying down, ...
        ProcessAgentState(agentPos, unum, idx);
   }

   // compute rank of distance to ball
   SimpleOrder(distArr, ordArr, idx);
   // compute rank of distance to own goal
   SimpleOrder(distGArr, ordGArr, idx);
}

void SoccerRuleAspect::AnalyseBallHoldingFouls()
{
    if (mBallState.get() == 0)
        return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, TI_NONE))
        return;

    Vector3f ballPos = mBallBody->GetPosition();

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;

    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        int unum = (*i)->GetUniformNumber();
        TTeamIndex idx = (*i)->GetTeamIndex();        
        
        if (distArr[unum][idx] < mBallHoldRadius && distArr[unum][idx] < closestPlayerDist[SoccerBase::OpponentTeam(idx)] && mGameState->GetPlayMode() == PM_PlayOn) {
            // Player is holding the ball
            
            float ballDistFromStart = 0.0;
            if (playerTimeSinceStartBallHold[unum][idx] == 0) {
                // Player just started holding the ball so record start position of the ball
                playerBallPosAtStartBallHold[unum][idx] = ballPos;
            } else {
                // Player was previously holding the ball so chck how far the ball has moved from its position when the ball was first held
                Vector3f startBallPos = playerBallPosAtStartBallHold[unum][idx];
                ballDistFromStart = sqrt((startBallPos.x()-ballPos.x())*(startBallPos.x()-ballPos.x()) +
                                         (startBallPos.y()-ballPos.y())*(startBallPos.y()-ballPos.y()));
            }

            bool goalieWithBallInPenaltyArea = false;
            if (unum == 1) 
            {
                // For goalie, check if ball is in own penalty area
                if (idx == TI_LEFT) {
                    goalieWithBallInPenaltyArea = ballPos.x() <= mLeftPenaltyArea.maxVec[0] && ballPos.y() >= mLeftPenaltyArea.minVec[1] && ballPos.y() <= mLeftPenaltyArea.maxVec[1];
                } else {
                    goalieWithBallInPenaltyArea = ballPos.x() >= mRightPenaltyArea.minVec[0] && ballPos.y() >= mRightPenaltyArea.minVec[1] && ballPos.y() <= mRightPenaltyArea.maxVec[1];
                }
            }

            float ballHoldMaxTime = mBallHoldMaxTime;
            if (goalieWithBallInPenaltyArea) {
                // Use different max holding time if goalie and ball is in own penalty area
                ballHoldMaxTime = mBallHoldGoalieMaxTime;
            }
            
            if ((playerTimeSinceStartBallHold[unum][idx] >= ballHoldMaxTime/.02 || ballDistFromStart >= mBallHoldMaxDistance)
                && (closestPlayerDist[SoccerBase::OpponentTeam(idx)] <= mBallHoldOppDistance || mBallHoldOppDistance < 0)) {
                // A ball holding foul has occurred
                playerFoulTime[unum][idx]++;
                playerLastFoul[unum][idx] = FT_BallHolding;

                if (!mBallHoldBeamPenalty) {
                    // Get agent position
                    std::shared_ptr<Transform> agent_aspect;
                    SoccerBase::GetTransformParent(**i, agent_aspect);
                    salt::Vector3f new_pos = agent_aspect->GetWorldTransform().Pos();
                    salt::Vector2f agent_pos = Vector2f(new_pos.x(),new_pos.y());

                    salt::Vector2f ballToAgentVec = salt::Vector2f(agent_pos.x()-ballPos.x(), agent_pos.y()-ballPos.y()).Normalize();
                    salt::Vector2f move_pos = agent_pos + ballToAgentVec*mAgentRadius;
                    new_pos[0] = move_pos[0];
                    new_pos[1] = move_pos[1];

                    MoveAgent(agent_aspect, new_pos);
                }
            }


            // Increment ball holding time for player
            playerTimeSinceStartBallHold[unum][idx]++;
            // Reset time since stopped holding ball
            playerTimeSinceStopBallHold[unum][idx] = 0;
        } else if (playerTimeSinceStartBallHold[unum][idx] > 0) {
            if (playerTimeSinceStopBallHold[unum][idx] >= mBallHoldResetTime/.02) {
                // Player has stopped holding the ball for long enough to reset so set holding time to 0
                playerTimeSinceStartBallHold[unum][idx] = 0;
            } else {
                // Increment time since stopped holding ball
                playerTimeSinceStopBallHold[unum][idx]++;
            }
        }
    }
}

void SoccerRuleAspect::AnalyseChargingFouls()
{
    if (!mUseCharging)
    {
        return;
    }

    if (mBallState.get() == 0)
        return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, TI_LEFT))
        return;

    // Initialize values that will be updates
    int playerTimeSinceLastBallTouch_new[12][3];
    memcpy(&playerTimeSinceLastBallTouch_new, &playerTimeSinceLastBallTouch, sizeof(playerTimeSinceLastBallTouch));
    int playerChargingTime_new[12][3];
    memcpy(&playerChargingTime_new, &playerChargingTime, sizeof(playerChargingTime));
    int playerFoulTime_new[12][3];
    memcpy(&playerFoulTime_new, &playerFoulTime, sizeof(playerFoulTime));
    EFoulType playerLastFoul_new[12][3];
    memcpy(&playerLastFoul_new, &playerLastFoul, sizeof(playerLastFoul));

    SoccerBase::TAgentStateList::iterator asIt = agent_states.begin();
    for (; asIt != agent_states.end(); ++asIt)
    {
        OpponentCollisionInfoVec& collisions = (*asIt)->GetOppCollisionPosInfoVec();
        
        if (collisions.empty()) {
            continue;
        }

        salt::Vector3f agentAvgVel[2];
        salt::Vector3f agentPos[2];
        float s[2]; //agentSpeed
        float d[2]; //agentDistToBall
        float aVB[2]; //agentAngleOfSpeedVectorToBall
        float aVO[2]; //agentAngleOfSpeedVectorToOpponent
        int agentUNum[2];
        TTeamIndex agentTeamIndex[2];
        bool isCharging[2]; // Boolean if an agent had committed a foul
        salt::Vector3f ballPos = mBallBody->GetPosition();
        
        int i = 0;
        // Start collision c counter at -1 which means we're collecting info for current agent not an opponent that 
        // has been collided with.
        for (int c = -1; c < (int)collisions.size(); c++)
        {
            std::shared_ptr<AgentState> agent_state;         
            if (c == -1) {
                agent_state = *asIt;
                i = 0;
            } else {
                if (!SoccerBase::GetAgentState(*mBallState.get(), SoccerBase::OpponentTeam(agentTeamIndex[0]),
                                                collisions[c].first, agent_state)) {
                    continue;
                }
                i = 1;
            }
            std::shared_ptr<Transform> transform_parent;
            std::shared_ptr<RigidBody> agent_body;
            SoccerBase::GetTransformParent(*agent_state, transform_parent);
            SoccerBase::GetAgentBody(transform_parent, agent_body);
            
            // Get agent uniform number and team index
            agentUNum[i] = agent_state->GetUniformNumber();
            agentTeamIndex[i] = agent_state->GetTeamIndex();

            // Get agent position
            agentPos[i] = agent_body->GetPosition();
            
            // Compute agent distance to ball
            d[i] = sqrt(pow(agentPos[i].x() - ballPos.x(), 2)
                        + pow(agentPos[i].y() - ballPos.y(), 2));
            
            // Get average agent velocity
            agentAvgVel[i] = salt::Vector3f(0,0,0);

            for(int j = 0; j < AVERAGE_VELOCITY_MEASUREMENTS; j++)
            {
            	agentAvgVel[i].x() = agentAvgVel[i].x() + playerVelocities[agentUNum[i]][agentTeamIndex[i]][j].x();
            	agentAvgVel[i].y() = agentAvgVel[i].y() + playerVelocities[agentUNum[i]][agentTeamIndex[i]][j].y();
            	agentAvgVel[i].z() = agentAvgVel[i].z() + playerVelocities[agentUNum[i]][agentTeamIndex[i]][j].z();
            }

            agentAvgVel[i].x() = agentAvgVel[i].x()/AVERAGE_VELOCITY_MEASUREMENTS;
            agentAvgVel[i].y() = agentAvgVel[i].y()/AVERAGE_VELOCITY_MEASUREMENTS;
            agentAvgVel[i].z() = agentAvgVel[i].z()/AVERAGE_VELOCITY_MEASUREMENTS;

            // Compute agent speed
            s[i] = sqrt(pow(agentAvgVel[i].x(), 2) + pow(agentAvgVel[i].y(), 2));
            
            // Compute speed vector angle to ball
            aVB[i] = abs(salt::gRadToDeg(salt::gNormalizeRad(
                                                             salt::gArcTan2(agentAvgVel[i].y(), agentAvgVel[i].x()) -
                                                             salt::gArcTan2(ballPos.y()-agentPos[i].y(), ballPos.x() - agentPos[i].x())
                                                             )));

            if (c == -1) {
                // Were just initializing values for first agent so go on to second agents
                continue;
            }

            if (playerNotStanding[agentUNum[0]][agentTeamIndex[0]] != 0
                || playerNotStanding[agentUNum[1]][agentTeamIndex[1]] != 0
                || playerTimeSinceLastWasMoved[agentUNum[0]][agentTeamIndex[0]] < 1/.02
                || playerTimeSinceLastWasMoved[agentUNum[1]][agentTeamIndex[1]] < 1/.02
                || HaveEnforceableFoul(agentUNum[0],agentTeamIndex[0])
                || HaveEnforceableFoul(agentUNum[1],agentTeamIndex[1]))
            {
                continue;
            }

            // Check if one of the agents is a goalie in their own penalty area
            bool goalieInOwnPenaltyArea[2];
            for (int i = 0; i <= 1; i++)
            {
                goalieInOwnPenaltyArea[i] = false;
                if (agentUNum[i] == 1) 
                {
                    // Could use playerInsideOwnArea[agentUNum[i]][agentTeamIndex[i]], however prefer to stretch the area for a goalie behind the goal line
                    if (agentTeamIndex[i] == TI_LEFT) {
                        if (agentPos[i].x() <= mLeftPenaltyArea.maxVec[0] && agentPos[i].y() >= mLeftPenaltyArea.minVec[1] && agentPos[i].y() <= mLeftPenaltyArea.maxVec[1]) {
                            goalieInOwnPenaltyArea[i] = true;
                            break;
                        }
                    } else if (agentTeamIndex[i] == TI_RIGHT) {
                        if (agentPos[i].x() >= mRightPenaltyArea.minVec[0] && agentPos[i].y() >= mRightPenaltyArea.minVec[1] && agentPos[i].y() <= mRightPenaltyArea.maxVec[1]) {
                            goalieInOwnPenaltyArea[i] = true;
                            break;
                        }
                    }
                }
            }
            
            // Compute speed vector angle to opponent
            for (i = 0; i <= 1; i++)
            {
                aVO[i] = abs(salt::gRadToDeg(salt::gNormalizeRad(
                                                                salt::gArcTan2(agentAvgVel[i].y(), agentAvgVel[i].x()) -
                                                                salt::gArcTan2(agentPos[1-i].y()-agentPos[i].y(),
                                                                                agentPos[1-i].x()-agentPos[i].x()))
                                            ));
            } 

            isCharging[0] = true;
            isCharging[1] = true;
            if(d[0] < mChargingMaxBallRulesDist || d[1] < mChargingMaxBallRulesDist)
            {
                for (int i = 0; i <= 1; i++)
                {
                    isCharging[i] = (aVB[i] >= aVO[i] && aVB[i] >= mChargingMinBallSpeedAngle && s[i] >= mChargingMinSpeed);
                }

                float deltaD;
                float deltaaVO;
                if (!isCharging[0] && !isCharging[1])
                {
                    // Handle case where both agents are apparently heading for the ball
                    deltaD = abs(d[0] - d[1]);
                    deltaaVO = abs(aVO[0] - aVO[1]);
                    
                    if(deltaD > mChargingMinDeltaDist)
                    {
                        isCharging[0] = d[0] > d[1] && (deltaaVO > mChargingMinDeltaAng || s[1] < mChargingMinSpeed);
                        isCharging[1] = d[1] > d[0] && (deltaaVO > mChargingMinDeltaAng || s[0] < mChargingMinSpeed);
                    }
                }
            }

            salt::Vector3f agentToCollisionVec[2];
            float agentCollisionSpeed[2];

            salt::Vector3f collPos = collisions[c].second.first;

            for (int i = 0; i <= 1; i++)
            {
                agentToCollisionVec[i] = salt::Vector3f((collPos.x()+agentPos[1-i].x())/2.0-agentPos[i].x(), (collPos.y()+agentPos[1-i].y())/2.0-agentPos[i].y(), 0);
                agentToCollisionVec[i].Normalize();
            }
            
            for (int i = 0; i <= 1; i++)
            {
                // Get collision speed
                agentCollisionSpeed[i] = agentAvgVel[i].x()*agentToCollisionVec[i].x() + agentAvgVel[i].y()*agentToCollisionVec[i].y();
                isCharging[i] = (isCharging[i]
                                && s[i] >= mChargingMinSpeed
                                && agentCollisionSpeed[i] >= mMinCollisionSpeed);                             
            }

#ifdef RVDRAW
            if (mRVSender) {
                mRVSender->clearStaticDrawings();
                for (auto& cInfo : (*asIt)->GetOppCollisionPosInfoVec())
                {
                    mRVSender->drawPoint(cInfo.second.first.x(), cInfo.second.first.y(), 10, RVSender::PINK);
                }
                if (mChargingMinCollBallDist > 0) {
                    mRVSender->drawCircle(ballPos.x(), ballPos.y(), mChargingMinCollBallDist, RVSender::ORANGE);
                }
                bool shade = goalieInOwnPenaltyArea[0] || playerTimeSinceLastBallTouch[agentUNum[0]][agentTeamIndex[0]] < mChargingImmunityTime/0.02 || playerChargingTime[agentUNum[0]][agentTeamIndex[0]] < mChargingCollisionMinTime/0.02;
                mRVSender->drawPoint(agentPos[0].x(), agentPos[0].y(), 10, agentTeamIndex[0] == TI_LEFT ? RVSender::BLUE : RVSender::RED, shade);
                mRVSender->drawLine(agentPos[0].x(), agentPos[0].y(), agentPos[0].x()+agentAvgVel[0].x(), agentPos[0].y()+agentAvgVel[0].y(), agentTeamIndex[0] == TI_LEFT ? RVSender::BLUE : RVSender::RED, shade);
                shade = goalieInOwnPenaltyArea[1] || playerTimeSinceLastBallTouch[agentUNum[1]][agentTeamIndex[1]] < mChargingImmunityTime/0.02;
                mRVSender->drawPoint(agentPos[1].x(), agentPos[1].y(), 10, agentTeamIndex[1] == TI_LEFT ? RVSender::BLUE : RVSender::RED, shade);
                mRVSender->drawLine(agentPos[1].x(), agentPos[1].y(), agentPos[1].x()+agentAvgVel[1].x(), agentPos[1].y()+agentAvgVel[1].y(), agentTeamIndex[1] == TI_LEFT ? RVSender::BLUE : RVSender::RED, shade);
                if (agentCollisionSpeed[0] > 0) {
                    mRVSender->drawLine(agentPos[0].x(), agentPos[0].y(), agentPos[0].x()+(agentCollisionSpeed[0]*agentToCollisionVec[0].x()), agentPos[0].y()+(agentCollisionSpeed[0]*agentToCollisionVec[0].y()), RVSender::YELLOW, !isCharging[0]);
                }
                if (agentCollisionSpeed[1] > 0) {
                    mRVSender->drawLine(agentPos[1].x(), agentPos[1].y(), agentPos[1].x()+(agentCollisionSpeed[1]*agentToCollisionVec[1].x()), agentPos[1].y()+(agentCollisionSpeed[1]*agentToCollisionVec[1].y()), RVSender::YELLOW, !isCharging[1]);
                }
            }
#endif // RVDRAW
            
            for (int i = 0; i <= 1; i++)
            {
                if (isCharging[i]) {
                    if (goalieInOwnPenaltyArea[i])
                    {
                        playerTimeSinceLastBallTouch_new[agentUNum[1-i]][agentTeamIndex[1-i]] = 0;
                    }
                    else if (playerTimeSinceLastBallTouch[agentUNum[i]][agentTeamIndex[i]] < mChargingImmunityTime/0.02)
                    {
                        playerTimeSinceLastBallTouch_new[agentUNum[1-i]][agentTeamIndex[1-i]] = min(playerTimeSinceLastBallTouch_new[agentUNum[1-i]][agentTeamIndex[1-i]],
                                                                                                playerTimeSinceLastBallTouch[agentUNum[i]][agentTeamIndex[i]]);
                    }
                    playerChargingTime_new[agentUNum[1-i]][agentTeamIndex[1-i]] = min(playerChargingTime_new[agentUNum[1-i]][agentTeamIndex[1-i]],
                                                                                playerChargingTime[agentUNum[i]][agentTeamIndex[i]]);
                }
            }
            
            float ballToCollDist = sqrt(pow(collPos.x()- ballPos.x(), 2)
                                        + pow(collPos.y() - ballPos.y(), 2));
        
            if((isCharging[0] && isCharging[1]) || ballToCollDist < mChargingMinCollBallDist) //Type 3
            {
                isCharging[0] = false;
                isCharging[1] = false;
            }

            for (int i = 0; i <= 1; i++)
            {
                if (mKeepaway && agentTeamIndex[i] == TI_RIGHT) 
                {
                    // Don't call charging fouls on agents trying to take ball
                    // during keepaway
                    continue;
                }
                
                if (isCharging[i] && !goalieInOwnPenaltyArea[i] && playerChargingTime[agentUNum[i]][agentTeamIndex[i]] >= mChargingCollisionMinTime/0.02
                    && playerTimeSinceLastBallTouch[agentUNum[i]][agentTeamIndex[i]] >= mChargingImmunityTime/0.02)
                {
                    playerFoulTime_new[agentUNum[i]][agentTeamIndex[i]] = playerFoulTime[agentUNum[i]][agentTeamIndex[i]]+1;
                    playerLastFoul_new[agentUNum[i]][agentTeamIndex[i]] = FT_Charging;
                }
            }

            if(!isCharging[0] && !isCharging[1])
            {
                playerChargingTime_new[agentUNum[0]][agentTeamIndex[0]] = 0;
                playerChargingTime_new[agentUNum[1]][agentTeamIndex[1]] = 0;
            }
        }
    }

    // Update values
    memcpy(&playerTimeSinceLastBallTouch, &playerTimeSinceLastBallTouch_new, sizeof(playerTimeSinceLastBallTouch_new));
    memcpy(&playerChargingTime, &playerChargingTime_new, sizeof(playerChargingTime_new));
    memcpy(&playerFoulTime, &playerFoulTime_new, sizeof(playerFoulTime_new));
    memcpy(&playerLastFoul, &playerLastFoul_new, sizeof(playerLastFoul_new));
}

void SoccerRuleAspect::AnalyseTouchGroups(TTeamIndex idx, bool fOnlyProcessNewlyJoinedGroupAgents)
{
    if (idx == TI_NONE || mBallState.get() == 0)
        return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    SoccerBase::TAgentStateList::iterator i = agent_states.begin();
    for (; i != agent_states.end(); ++i)
    {
        std::shared_ptr<TouchGroup> touchGroup = (*i)->GetTouchGroup();

        if (HaveEnforceableFoul((*i)->GetUniformNumber(),idx)) {
            // Once a player has been called for a foul don't check for
            // additional fouls
            
            if (touchGroup->size() > 1) {
                // Remove player from touch group so no more agents are replaced
                touchGroup->erase(*i);
            }

            continue;
        }

        // Wasn't touching before, joined group making group too large
        if (((*i)->GetOldTouchGroup()->size() == 1 || !fOnlyProcessNewlyJoinedGroupAgents) &&
            (int)touchGroup->size() > mMaxTouchGroupSize)
        {
            // determine the team that has more players in the touch group
            int pl[3] = { 0 };
            SoccerBase::TAgentStateList::iterator oppIt; // stores the last opponent in touch group
            SoccerBase::TAgentStateList::iterator teammateIt; // stores the last teammate in touch group

            int numPlayersCommittedFoul = 0;
            salt::Vector3f agentsPosSum = salt::Vector3f(0,0,0);

            // Randomize order of agent states in touch group to remove any bias in order before processing
            SoccerBase::TAgentStateList touchGroupList(touchGroup->begin(), touchGroup->end());
            shuffle(touchGroupList.begin(), touchGroupList.end(), mRng);

            for (SoccerBase::TAgentStateList::iterator agentIt = touchGroupList.begin();
                    agentIt != touchGroupList.end(); ++agentIt)
            {
                if (HaveEnforceableFoul((*agentIt)->GetUniformNumber(),(*agentIt)->GetTeamIndex())) 
                {
                    // Don't count players who have committed fouls
                    numPlayersCommittedFoul++;
                    continue;
                }   

                // Get agent position
                std::shared_ptr<Transform> agent_aspect;
                SoccerBase::GetTransformParent(*(*agentIt), agent_aspect);
                agentsPosSum += agent_aspect->GetWorldTransform().Pos();
                
                pl[(*agentIt)->GetTeamIndex()]++;
                
                // Only call touching foul on non-goalies in group
                if ((*agentIt)->GetUniformNumber() != 1 || mMaxTouchGroupSize < 2) 
                {
                    if ((*agentIt)->GetTeamIndex() != idx)
                    {
                        oppIt = agentIt;
                    } 
                    else 
                    {
                        teammateIt = agentIt;
                    }
                }
            }

            if ((int)touchGroup->size()-numPlayersCommittedFoul <= mMaxTouchGroupSize)
            {
                // Not enough players who haven't already committed fouls in 
                // group to call a touching foul
                continue;
            }   

            salt::Vector3f agentsPosAvg = agentsPosSum/(touchGroup->size()-numPlayersCommittedFoul);

            if (pl[idx] >= (int)touchGroup->size() - pl[idx])
            {
                if ((*i)->GetUniformNumber() == 1 && mMaxTouchGroupSize > 1) 
                {
                    // I am the last one to enter the group, but remove teammate as
                    // I'm the goalie
                    PenalizeTouchingFoul(*teammateIt, agentsPosAvg);
                    
                    // Remove player from touch group so no more agents are replaced
                    touchGroup->erase(*teammateIt);
                }
                else 
                {
                    PenalizeTouchingFoul(*i, agentsPosAvg);
                    
                    // Remove player from touch group so no more agents are replaced
                    touchGroup->erase(*i);
                }
            }
            else
            {
                // I am the last one to enter the group, but the number of
                // opponents in the group are more than us
                PenalizeTouchingFoul(*oppIt, agentsPosAvg);

                // Remove player from touch group so no more agents are replaced
                touchGroup->erase(*oppIt);
            }
        }
    }

    
    if (fOnlyProcessNewlyJoinedGroupAgents) {
        i = agent_states.begin();
        for (; i != agent_states.end(); ++i)
        {
            if ((int)(*i)->GetTouchGroup()->size() > mMaxTouchGroupSize) {
                AnalyseTouchGroups(idx, false /*fOnlyProcessNewlyJoinedGroupAgents*/);
                break;
            }
        }
    }
    
}

void SoccerRuleAspect::ResetTouchGroups(TTeamIndex idx)
{
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); i++)
    {   
        (*i)->GetOppCollisionPosInfoVec().clear();
        (*i)->NewTouchGroup();
        (*i)->GetTouchGroup()->insert(*i);
    }
}

void SoccerRuleAspect::PenalizeTouchingFoul(std::shared_ptr<AgentState> agentState, const salt::Vector3f touchGroupCenter)
{
    int unum = agentState->GetUniformNumber();
    TTeamIndex ti = agentState->GetTeamIndex();
    playerFoulTime[unum][ti]++;
    playerLastFoul[unum][ti] = FT_Touching;

    if (!mTouchingFoulBeamPenalty) {
        // Get agent position
        std::shared_ptr<Transform> agent_aspect;
        SoccerBase::GetTransformParent(*agentState, agent_aspect);
        salt::Vector3f new_pos = agent_aspect->GetWorldTransform().Pos();
        salt::Vector2f agent_pos = Vector2f(new_pos.x(),new_pos.y());

        salt::Vector2f groupToAgentVec = salt::Vector2f(agent_pos.x()-touchGroupCenter.x(), agent_pos.y()-touchGroupCenter.y()).Normalize();
        salt::Vector2f move_pos = agent_pos + groupToAgentVec*mAgentRadius;
        new_pos[0] = move_pos[0];
        new_pos[1] = move_pos[1];

        MoveAgent(agent_aspect, new_pos);
    }
}

void SoccerRuleAspect::GetTreeBoxColliders(std::shared_ptr<zeitgeist::Leaf> root, 
                                 vector< std::shared_ptr<BoxCollider> > &agentBoxes) {
    if(root==0) return;
    
    if(root->GetClass()->GetName()=="BoxCollider") {
        std::shared_ptr<BoxCollider> boxC = std::static_pointer_cast<BoxCollider>(root);
        agentBoxes.push_back (boxC) ; 
     
    }

    auto node_it = root->begin();
    auto node_it_end = root->end();

    for (; node_it != node_it_end; node_it++) {
        GetTreeBoxColliders(*node_it, agentBoxes);
    }
}

void SoccerRuleAspect::AnalyseSelfCollisionFouls(TTeamIndex idx)
{
    if (idx == TI_NONE || mBallState.get() == 0)
        return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;

    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);

        vector< std::shared_ptr<BoxCollider> > agentBoxes;
        vector< std::string > partNames;

        int unum = (*i)->GetUniformNumber();
        
        TLeafList parts;
        std::shared_ptr<zeitgeist::Node> a2 = agent_aspect->GetParent().lock();
        std::shared_ptr<zeitgeist::Node> a3 = a2->GetParent().lock();

        GetTreeBoxColliders(a3, agentBoxes);

        unsigned int b1, b2;
        for (b1 = 0; b1 < agentBoxes.size(); b1++)
        {
            for (b2 = b1 + 1; b2 < agentBoxes.size(); b2++)
            {
                std::shared_ptr<oxygen::Transform> box1_transform, box2_transform;

                SoccerBase::GetTransformParent(*agentBoxes[b1], box1_transform);
                SoccerBase::GetTransformParent(*agentBoxes[b2], box2_transform);
                if (agentBoxes[b2]->InNotCollideWithSet(agentBoxes[b1]))
                    continue;
                if (agentBoxes[b1]->CheckCollisions(agentBoxes[b2], mSelfCollisionsTolerance))
                {
                    playerSelfCollisions[unum][idx]++;
                    if (mPrintSelfCollisions)
                    {
                        GetLog()->Error() << "ANALYSECOLLISIONS: Collision GTime " << mGameState->GetTime()
                                          << " Team " << idx << " Pl " << unum
                                          << " " << box1_transform->GetName()
                                          << " " << box2_transform->GetName()
                                          << endl;
                    }
                    if (mWriteSelfCollisionsToFile)
                    {
                        selfCollisionsFile << "Collision GTime " << mGameState->GetTime()
                                           << " Team " << mGameState->GetTeamName(idx) << " Pl " << unum
                                           << " " << box1_transform->GetName()
                                           << " " << box2_transform->GetName()
                                           << endl;
                    }
                    if (mFoulOnSelfCollisions)
                    {
                        if (mSelfCollisionBeamPenalty && mGameState->GetTime() - playerTimeLastSelfCollision[unum][idx] > mSelfCollisionBeamCooldownTime)
                        {
                            playerTimeLastSelfCollision[unum][idx] = mGameState->GetTime();
                            playerFoulTime[unum][idx]++;
                            playerLastFoul[unum][idx] = FT_SelfCollision;
                            if (mWriteSelfCollisionsToFile)
                            {
                                selfCollisionsFile << "Foul Team " << mGameState->GetTeamName(idx) << " Pl " << unum << " GTime " << mGameState->GetTime() << endl;
                            }
                        }

                        if (!mSelfCollisionBeamPenalty)
                        {
                            bool haveFoul = false;
                            std::shared_ptr<oxygen::AgentAspect> agent = NULL;
                            bool noAgentJointControlFound = false;
                            std::list<std::string> jointsCollidedList = agentBoxes[b1]->GetSCFreezeJointEffNames();
                            std::list<std::string> jointsCollidedList2 = agentBoxes[b2]->GetSCFreezeJointEffNames();
                            jointsCollidedList.insert(jointsCollidedList.end(), jointsCollidedList2.begin(), jointsCollidedList2.end());

                            std::list<std::string>::const_iterator itj;
                            for (itj = jointsCollidedList.begin(); itj != jointsCollidedList.end(); ++itj)
                            {
                                std::string jointName = *itj;
                                if (lastTimeJointFrozen[unum][idx].find(jointName) == lastTimeJointFrozen[unum][idx].end() || mGameState->GetTime() - lastTimeJointFrozen[unum][idx][jointName] > mSelfCollisionJointFrozenTime + mSelfCollisionJointThawTime)
                                {
                                    haveFoul = true;
                                    //playerFoulTime[unum][idx]++;
                                    //playerLastFoul[unum][idx] = FT_SelfCollision;

                                    lastTimeJointFrozen[unum][idx][jointName] = mGameState->GetTime();

                                    if (noAgentJointControlFound)
                                    {
                                        continue;
                                    }

                                    if (!agent)
                                    {
                                        std::shared_ptr<GameControlServer> game_control;

                                        if (!SoccerBase::GetGameControlServer(*this, game_control))
                                        {
                                            noAgentJointControlFound = true;
                                            continue;
                                        }

                                        GameControlServer::TAgentAspectList agentAspects;
                                        game_control->GetAgentAspectList(agentAspects);
                                        GameControlServer::TAgentAspectList::iterator aaiter;
                                        for (aaiter = agentAspects.begin(); aaiter != agentAspects.end(); ++aaiter)
                                        {
                                            std::shared_ptr<AgentState> agentState =
                                                std::dynamic_pointer_cast<AgentState>((*aaiter)->GetChild("AgentState", true));

                                            if (agentState->GetUniformNumber() == unum && agentState->GetTeamIndex() == idx)
                                            {
                                                agent = std::static_pointer_cast<oxygen::AgentAspect>(*aaiter);
                                                break;
                                            }
                                        }
                                    }

                                    if (!agent)
                                    {
                                        noAgentJointControlFound = true;
                                        continue;
                                    }

                                    std::shared_ptr<oxygen::Effector> effector = std::dynamic_pointer_cast<oxygen::Effector>(agent->GetEffector(jointName));
                                    if (effector)
                                    {
                                        effector->Disable();
                                    }
                                }
                            }

                            if (haveFoul)
                            {
                                // Record foul
                                mFouls.push_back(Foul(mFouls.size() + 1, FT_SelfCollision, *i));
                                if (mWriteSelfCollisionsToFile)
                                {
                                    selfCollisionsFile << "Foul Team " << mGameState->GetTeamName(idx) << " Pl " << unum << " GTime " << mGameState->GetTime() << endl;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Analyse Fouls and Creates Foul Time Array
void SoccerRuleAspect::AnalyseFouls(TTeamIndex idx)
{
    TTeamIndex idx2 = SoccerBase::OpponentTeam(idx); // //Other team   
    
    // Randomize order of agents evaluated
    std::vector<unsigned int> unums(11);
    for (unsigned int i = 0; i < unums.size(); i++) {unums[i] = i+1;}
    shuffle(unums.begin(), unums.end(), mRng);

    for(std::vector<unsigned int>::const_iterator it = unums.begin(); it != unums.end(); ++it)
    {
        unsigned int unum = *it;

        if (HaveEnforceableFoul(unum,idx)) 
        {
            // Once a player has been called for a foul don't check for
            // additional fouls
            continue;
        }

        TPlayMode playMode = mGameState->GetPlayMode();
        bool checkCrowding = (playMode == PM_KickOff_Left && idx != TI_LEFT)
            || (playMode == PM_KickOff_Right && idx != TI_RIGHT)
            || (playMode != PM_KickOff_Left && playMode != PM_KickOff_Right);
 
        // I am the third closest player but i am too near the ball (and not the goalie)
        if (checkCrowding && unum != 1 && closestPlayerDist[idx2] < mMinOppDistance
            && (distArr[unum][idx] <= mMin3PlDistance + 0.01
                && ordArr[unum][idx] == 3))
        {
                playerFoulTime[unum][idx]++;
                playerLastFoul[unum][idx] = FT_Crowding;
        }
        // I am the second closest player but i am too near the ball (and not the goalie)
        else if (checkCrowding && unum != 1 && closestPlayerDist[idx2] < mMinOppDistance
                 && distArr[unum][idx] <= mMin2PlDistance + 0.01
                 && ordArr[unum][idx] == 2)
        {
                playerFoulTime[unum][idx]++;
                playerLastFoul[unum][idx] = FT_Crowding;
        } 
        // Too many players inside my own penalty area and Im am the last one to enter or
        // the last one to enter was the goalie and I am the one further away from own goal
        else if((numPlInsideOwnArea[idx] > mMaxPlayersInsideOwnArea && unum != 1 && playerInsideOwnArea[unum][idx] == 1 &&
                (prevPlayerInsideOwnArea[unum][idx] == 0 ||
                 (prevPlayerInsideOwnArea[1][idx] == 0 && playerInsideOwnArea[1][idx] == 1 && mMaxPlayersInsideOwnArea + 1 == ordGArr[unum][idx]))))
        {
            PenalizeIllegelDefenseFoul(unum, idx);
        }
        // I am a field player and on the ground for too much time
        else if (unum != 1 && playerGround[unum][idx] > mGroundMaxTime / 0.02)
        {
            playerFoulTime[unum][idx]++;
            playerLastFoul[unum][idx] = FT_Incapable;
        }
        // I am a field player and I am not standing for too much time
        else if(unum!=1 && playerNotStanding[unum][idx] > mNotStandingMaxTime / 0.02)
        {
            playerFoulTime[unum][idx]++;
            playerLastFoul[unum][idx] = FT_Incapable;
        }
        // I am the goalie and I am on the ground for too much time
        else if (unum == 1 && playerGround[unum][idx] > mGoalieGroundMaxTime / 0.02)
        {
            playerFoulTime[unum][idx]++;
            playerLastFoul[unum][idx] = FT_Incapable;
        }
        // I am the goalie and I and not standing for too much time
        else if (unum == 1 && playerNotStanding[unum][idx] > mGoalieNotStandingMaxTime / 0.02)
        {
            playerFoulTime[unum][idx]++;
            playerLastFoul[unum][idx] = FT_Incapable;
        }
        else
        {
            playerFoulTime[unum][idx]=0;
            playerLastFoul[unum][idx] = FT_None;
        }
    }
}

void SoccerRuleAspect::PenalizeIllegelDefenseFoul(int unum, TTeamIndex idx)
{
    playerFoulTime[unum][idx]++;
    playerLastFoul[unum][idx] = FT_IllegalDefence;
    numPlInsideOwnArea[idx]--;

    if (!mIllegalDefenseBeamPenalty) {
        std::shared_ptr<AgentState> agent_state;
        if (!SoccerBase::GetAgentState(*mBallState.get(), idx, unum, agent_state))
            return;

        // Get agent position
        std::shared_ptr<Transform> agent_aspect;
        SoccerBase::GetTransformParent(*agent_state, agent_aspect);
        salt::Vector3f new_pos = agent_aspect->GetWorldTransform().Pos();
        salt::Vector2f agent_pos = Vector2f(new_pos.x(),new_pos.y());

        salt::AABB2 penaltyArea = idx == TI_LEFT ? mLeftPenaltyArea : mRightPenaltyArea;

        const float PAD = mAgentRadius;

        float closestXTarget = abs(penaltyArea.minVec.x()-agent_pos.x()) < abs(penaltyArea.maxVec.x()-agent_pos.x()) ? penaltyArea.minVec.x()-PAD : penaltyArea.maxVec.x()+PAD;
        float closestYTarget = abs(penaltyArea.minVec.y()-agent_pos.y()) < abs(penaltyArea.maxVec.y()-agent_pos.y()) ? penaltyArea.minVec.y()-PAD : penaltyArea.maxVec.y()+PAD;

        salt::Vector2f box_edge_pos;
        if (abs(closestYTarget-agent_pos.y()) < abs(closestXTarget-agent_pos.x())) {
            new_pos.y() = closestYTarget;
        } else {
            new_pos.x() = closestXTarget;
        }

        if (abs(new_pos.x()) > mFieldLength/2.0 && abs(new_pos.y()) < (mGoalWidth/2.0 + mAgentRadius)) {
            // Move position to not be inside goal
            new_pos.y() = (mGoalWidth/2.0 + mAgentRadius + 0.001) * (new_pos.y() < 0 ? -1 : 1);
        }

        MoveAgent(agent_aspect, new_pos);
    }
}


salt::Vector3f SoccerRuleAspect::RepositionOutsidePos(salt::Vector3f posIni, int unum, TTeamIndex idx)
{
    salt::Vector3f pos;
    // Choose x side based on team
    float xFac = idx == TI_LEFT ? -0.6 : 0.6;
    // Choose side on oppisite side of field
    float yFac = posIni.y() < 0 ? 1.0 : -1.0;

    pos = Vector3f(xFac * (7 - unum), (mFieldWidth / 2 + 0.5) * yFac, 1.0);

    return pos;
}


bool SoccerRuleAspect::GetSafeRepositionHelper_AdjustPositionForPenaltyArea(const salt::Vector2f agent_pos, int unum, TTeamIndex idx, salt::Vector2f &current_pos)
{
    // Check that we're not being moved into our penalty area when there
    // are already the maximum number of teammates allowed in the penalty 
    // area
    if (playerInsideOwnArea[unum][idx] == 0 && numPlInsideOwnArea[idx]+numPlReposInsideOwnArea[idx] >= mMaxPlayersInsideOwnArea) {
        if ((idx == TI_LEFT
             && current_pos.x() > mLeftPenaltyArea.minVec[0]-mAgentRadius 
             && current_pos.x() < mLeftPenaltyArea.maxVec[0]+mAgentRadius
             && current_pos.y() > mLeftPenaltyArea.minVec[1]-mAgentRadius
             && current_pos.y() < mLeftPenaltyArea.maxVec[1]+mAgentRadius)
            || (idx == TI_RIGHT 
                && current_pos.x() > mRightPenaltyArea.minVec[0]-mAgentRadius 
                && current_pos.x() < mRightPenaltyArea.maxVec[0]+mAgentRadius
                && current_pos.y() > mRightPenaltyArea.minVec[1]-mAgentRadius
                && current_pos.y() < mRightPenaltyArea.maxVec[1]+mAgentRadius)) {
            /*
#ifdef RVDRAW
            if (mRVSender) {
                //mRVSender->clearStaticDrawings();
                mRVSender->drawPoint(current_pos.x(), current_pos.y(), 10, RVSender::YELLOW);
            }
#endif
            */
            if (idx == TI_LEFT) {
                if (current_pos.x() > agent_pos.x()) {
                    // Move beyond the top of the penalty area
                    current_pos[0] = mLeftPenaltyArea.maxVec[0]+mAgentRadius;
                } else {
                    // Move to a side of the penalty area
                    if (current_pos.y() > agent_pos.y() || (current_pos.y() == agent_pos.y() && current_pos.y() < 0)) {
                        current_pos[1] = mLeftPenaltyArea.maxVec[1]+mAgentRadius;
                    } else {
                        current_pos[1] = mLeftPenaltyArea.minVec[1]-mAgentRadius; 
                    }
                }
            } else {
                if (current_pos.x() < agent_pos.x()) {
                    // Move beyond the top of the penalty area
                    current_pos[0] = mRightPenaltyArea.minVec[0]-mAgentRadius;
                } else {
                    // Move to a side of the penalty area
                    if (current_pos.y() > agent_pos.y() || (current_pos.y() == agent_pos.y() && current_pos.y() < 0)) {
                        current_pos[1] = mRightPenaltyArea.maxVec[1]+mAgentRadius;
                    } else {
                        current_pos[1] = mRightPenaltyArea.minVec[1]-mAgentRadius; 
                    }
                }
            }    
            return true;
        }
    }
    return false;
}

void SoccerRuleAspect::GetSafeRepositionHelper_SamplePositions(const salt::Vector2f agent_pos, int unum, TTeamIndex idx, salt::Vector2f current_pos, std::list<salt::Vector2f> &candidatePosList) 
{
    std::list<salt::Vector2f> newPosList;
    salt::Vector2f agent_pos_xmove = current_pos;
    if (idx == TI_LEFT) {
        agent_pos_xmove[0] = current_pos.x() + mAgentRadius * (agent_pos.x() < current_pos.x() ? 1 : -1);
    } else {
        agent_pos_xmove[0] = current_pos.x() + mAgentRadius * (agent_pos.x() > current_pos.x() ? -1 : 1);
    }
    if (abs(agent_pos_xmove.x()) <= mFieldLength/2.0) {
        GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, agent_pos_xmove);
        newPosList.push_back(agent_pos_xmove);
    }

    if (current_pos.x() == agent_pos.x()) {
        // Also add x position moving in other direction
        salt::Vector2f agent_pos_xmove2 = current_pos;
        if (idx == TI_LEFT) {
            agent_pos_xmove2[0] = current_pos.x() + mAgentRadius;
        } else {
            agent_pos_xmove2[0] = current_pos.x() - mAgentRadius;
        }
        if (abs(agent_pos_xmove2.x()) <= mFieldLength/2.0) {
            GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, agent_pos_xmove2);
            newPosList.push_back(agent_pos_xmove2);
        }
    }
        
    salt::Vector2f agent_pos_ymove = current_pos;
    if (current_pos.y() == agent_pos.y()) {
        // Move towards the center of the field
        agent_pos_ymove[1] = current_pos.y() + mAgentRadius * (agent_pos.y() < 0 ? 1 : -1);
        GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, agent_pos_ymove);
        newPosList.push_back(agent_pos_ymove);
        
        // Move away from the center of the field
        salt::Vector2f agent_pos_ymove2 = current_pos;
        agent_pos_ymove2[1] = current_pos.y() + mAgentRadius * (agent_pos.y() < 0 ? -1 : 1);
        GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, agent_pos_ymove2);
        newPosList.push_back(agent_pos_ymove2);
    } else {
        agent_pos_ymove[1] = current_pos.y() + mAgentRadius * (agent_pos.y() < current_pos.y() ? 1 : -1);
        GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, agent_pos_ymove);
        newPosList.push_back(agent_pos_ymove);
    }

    std::list<salt::Vector2f>::const_iterator i;
    for (i = newPosList.begin(); i != newPosList.end(); ++i) {
        salt::Vector2f newPos = *i;
        float newPosDistToAgent = sqrt((newPos.x()-agent_pos.x())*(newPos.x()-agent_pos.x()) +
                                       (newPos.y()-agent_pos.y())*(newPos.y()-agent_pos.y()));
        bool fAddPos = true;
        std::list<salt::Vector2f>::reverse_iterator c;
        for (c = candidatePosList.rbegin(); c != candidatePosList.rend(); ++c) {
            salt::Vector2f candidatePos = *c;
            float candidatePosDistToNewPos = sqrt((candidatePos.x()-newPos.x())*(candidatePos.x()-newPos.x()) + 
                                                  (candidatePos.y()-newPos.y())*(candidatePos.y()-newPos.y()));
            if (candidatePosDistToNewPos < mAgentRadius/2.0) {
                fAddPos = false;
                break;
            }
                
            float candidatePosDistToAgent = sqrt((candidatePos.x()-agent_pos.x())*(candidatePos.x()-agent_pos.x()) +
                                       (candidatePos.y()-agent_pos.y())*(candidatePos.y()-agent_pos.y()));
            if (newPosDistToAgent >= candidatePosDistToAgent) {
                break;
            }
        }
        if (fAddPos) {
            /*
#ifdef RVDRAW
            if (mRVSender) {
                //mRVSender->clearStaticDrawings();
                mRVSender->drawPoint(newPos.x(), newPos.y(), 10, RVSender::LIGHTBLUE);
            }
#endif
            */
            candidatePosList.insert(c.base(), newPos);
        }

        /*
        std::list<salt::Vector2f>::const_iterator d;
        std::cout << "-----------------\n";
        for (d = candidatePosList.begin(); d != candidatePosList.end(); ++d) {
            salt::Vector2f candidatePos = *d;
            float candidatePosDistToAgent = sqrt((candidatePos.x()-agent_pos.x())*(candidatePos.x()-agent_pos.x()) +
                                                 (candidatePos.y()-agent_pos.y())*(candidatePos.y()-agent_pos.y()));
            std::cout << candidatePosDistToAgent << "\n";
        }
        std::cout << "-----------------\n";
        */
    } 
}

salt::Vector3f SoccerRuleAspect::GetSafeReposition(salt::Vector3f posIni, int unum, TTeamIndex idx, bool fAvoidBall)
{
    salt::Vector3f pos = posIni;
    if (mMaxNumSafeRepositionAttempts == 0 || idx == TI_NONE || mBallState.get() == 0 || mAgentRadius <= 0)
        return pos;

    salt::Vector3f agentPos = Vector3f(0,0,0);
    std::shared_ptr<AgentState> agent_state;
    if (SoccerBase::GetAgentState(*mBallState.get(), idx, unum, agent_state)) {
        std::shared_ptr<oxygen::Transform> agent_aspect;
        SoccerBase::GetTransformParent(*agent_state, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);
        agentPos = agent_body->GetPosition();
    } else {
        return pos;
    }

    std::list<salt::Vector2f> candidatePosList;

    Vector2f agent_pos = Vector2f(agentPos.x(),agentPos.y());
    Vector2f initial_pos = Vector2f(posIni.x(),posIni.y());
    bool fUnsafePosition = GetSafeRepositionHelper_AdjustPositionForPenaltyArea(agent_pos, unum, idx, initial_pos);
    if (fUnsafePosition) {
        Vector2f current_pos = Vector2f(posIni.x(),posIni.y());
        GetSafeRepositionHelper_SamplePositions(agent_pos, unum, idx, current_pos, candidatePosList);
        if (candidatePosList.empty()) {
            GetLog()->Error() << "ERROR: (SoccerRuleAspect) Failed to safely reposition player " << unum << " " << (idx == TI_LEFT ? "(left)" : "(right)") << "\n";
            return posIni;
        }
        Vector2f candidatePos = candidatePosList.front();
        candidatePosList.pop_front();
        pos[0] = candidatePos.x();
        pos[1] = candidatePos.y();
    }

    // Count the number of times we've repositioned an agent from colliding, 
    // and bound this so as to avoid the possibility of an infinite loop
    int repositionAttempts = 0;
    while (repositionAttempts < mMaxNumSafeRepositionAttempts) {
        fUnsafePosition = false;
        SoccerBase::TAgentStateList agent_states;
        salt::BoundingSphere sphere(pos, mAgentRadius);

        if (abs(pos.x()) > mFieldLength/2.0 && abs(pos.y()) < (mGoalWidth/2.0 + mAgentRadius)) {
            // Don't allow positions inside/behind goal
            fUnsafePosition = true;
        }

        if (!fUnsafePosition && fAvoidBall) {
            salt::Vector3f ball_pos = mBallBody->GetPosition();                 
            float dist = sqrt((ball_pos.x()-pos.x())*(ball_pos.x()-pos.x()) +
                                (ball_pos.y()-pos.y())*(ball_pos.y()-pos.y()));
            if (dist < max(mAgentRadius*2, mPassModeMinOppBallDist)) {
                /*
#ifdef RVDRAW
                if (mRVSender) {
                    //mRVSender->clearStaticDrawings();
                    mRVSender->drawPoint(pos.x(), pos.y(), 10, RVSender::ORANGE);
                }
#endif
                */
                fUnsafePosition = true;
            }
        }

        // Check for collisions with teammates
        if (!fUnsafePosition && SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx)) {
            SoccerBase::TAgentStateList::const_iterator i;

            for (i = agent_states.begin(); i != agent_states.end(); ++i)
            {
                int unumAgent = (*i)->GetUniformNumber();
                if (unum == unumAgent) {
                    continue;
                }

                std::shared_ptr<oxygen::Transform> agent_aspect;
                SoccerBase::GetTransformParent(**i, agent_aspect);
                std::shared_ptr<RigidBody> agent_body;
                SoccerBase::GetAgentBody(agent_aspect, agent_body);
                Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
                AABB3 agentAABB = SoccerBase::GetAgentBoundingBox(*agent_aspect);
                agentAABB.Translate(moved_adjustment);

                if (sphere.Intersects(agentAABB)) {
                    /*
#ifdef RVDRAW
                    if (mRVSender) {
                        //mRVSender->clearStaticDrawings();
                        mRVSender->drawPoint(pos.x(), pos.y(), 10, RVSender::RED);
                    }
#endif
                    */
                    fUnsafePosition = true;
                    break;
                }
            }
        }

        // Check for collision with opponents
        agent_states.clear();
        if (!fUnsafePosition && SoccerBase::GetAgentStates(*mBallState.get(), agent_states, SoccerBase::OpponentTeam(idx))) {
            SoccerBase::TAgentStateList::const_iterator i;

            for (i = agent_states.begin(); i != agent_states.end(); ++i)
            {
                std::shared_ptr<oxygen::Transform> agent_aspect;
                SoccerBase::GetTransformParent(**i, agent_aspect);
                std::shared_ptr<RigidBody> agent_body;
                SoccerBase::GetAgentBody(agent_aspect, agent_body);
                Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
                AABB3 agentAABB = SoccerBase::GetAgentBoundingBox(*agent_aspect);
                agentAABB.Translate(moved_adjustment);

                if (sphere.Intersects(agentAABB)) {
#ifdef RVDRAW
                    if (mRVSender) {
                        //mRVSender->clearStaticDrawings();
                        mRVSender->drawPoint(pos.x(), pos.y(), 10, RVSender::RED);
                    }
#endif
                    fUnsafePosition = true;
                    break;
                }
            }
        }

        if (fUnsafePosition) {
            Vector2f current_pos = Vector2f(pos.x(),pos.y());
            GetSafeRepositionHelper_SamplePositions(agent_pos, unum, idx, current_pos, candidatePosList);
        }

        if (!fUnsafePosition || candidatePosList.empty()) {
            break;
        }
            
        Vector2f candidatePos = candidatePosList.front();
        candidatePosList.pop_front();
        pos[0] = candidatePos.x();
        pos[1] = candidatePos.y();
        repositionAttempts++;
    }

    //std::cout << repositionAttempts << "\n";

    if (fUnsafePosition) {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Failed to safely reposition player " << unum << " " << (idx == TI_LEFT ? "(left)" : "(right)") << "\n";
        pos = posIni;
    }
  
    if (playerInsideOwnArea[unum][idx] == 0 && ((idx == TI_LEFT && mLeftPenaltyArea.Contains(Vector2f(pos.x(), pos.y()))) ||
                                                (idx == TI_RIGHT && mRightPenaltyArea.Contains(Vector2f(pos.x(), pos.y())))))
    {
        numPlReposInsideOwnArea[idx]++;
    }
    else if (playerInsideOwnArea[unum][idx] == 1 && ((idx == TI_LEFT && !mLeftPenaltyArea.Contains(Vector2f(pos.x(), pos.y()))) ||
                                                     (idx == TI_RIGHT && !mRightPenaltyArea.Contains(Vector2f(pos.x(), pos.y())))))
    {
        numPlReposInsideOwnArea[idx]--;
    }

    return pos;
}


// Clear Players that are violating the rules
void
SoccerRuleAspect::ClearPlayersAutomatic(TTeamIndex idx)
{
    if (idx == TI_NONE || mBallState.get() == 0)
        return;

    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    salt::Vector3f ballPos = mBallBody->GetPosition();

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;

    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);
        Vector3f agentPos = agent_body->GetPosition();
        int unum = (*i)->GetUniformNumber();

        if (HaveEnforceableFoul(unum,idx))
        {
            // Record foul
            mFouls.push_back(Foul(mFouls.size() + 1, playerLastFoul[unum][idx], *i));

            bool fNoClear = (playerLastFoul[unum][idx] == FT_IllegalDefence && !mIllegalDefenseBeamPenalty)
                            || (playerLastFoul[unum][idx] == FT_Touching && !mTouchingFoulBeamPenalty)
                            || (playerLastFoul[unum][idx] == FT_BallHolding && !mBallHoldBeamPenalty);
            
            if (fNoClear) {
                ResetFoulCounterPlayer(unum, idx);
            } else {
                if (playerFoulTime[unum][idx] <= mFoulHoldTime/0.02) {
                    playerFoulTime[unum][idx]++;
                    agentPos[2] = 1.0 + playerFoulTime[unum][idx]*0.01;
                    MoveAgent(agent_aspect, agentPos, false /*fSafe*/);
                } else {
                    // I am not a very good soccer player... I am violating the rules...
                    salt::Vector3f new_pos = RepositionOutsidePos(ballPos, unum, idx);
                    //Calculate my Reposition pos outside of the field
                    if (mFoulHoldTime > 0) {
                        new_pos[2] = mAgentRadius;
                    }
                    //Oh my God!! I am flying!! I am going outside of the field
                    MoveAgent(agent_aspect, new_pos);
                    
                    ResetFoulCounterPlayer(unum, idx);
                    //cout << "*********Player Repos Num: " << unum << "  Team: " << team << "  Pos: " << new_pos << endl;
                }
            }
        }
    }
}

void
SoccerRuleAspect::ClearPlayers(const salt::Vector3f& pos, float radius,
                               float min_dist, TTeamIndex idx)
{
    if (idx == TI_NONE || mBallState.get() == 0) return;

    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    salt::BoundingSphere sphere(pos, radius);
    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);
        Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
        AABB3 agentAABB = SoccerBase::GetAgentBoundingBox(*agent_aspect);
        agentAABB.Translate(moved_adjustment);

        // if agent is too close, move it away
        Vector3f new_pos = agent_body->GetPosition();
        if (sphere.Intersects(agentAABB))
        {
            float dist = min_dist; //salt::UniformRNG<>(min_dist, min_dist + 2.0)();

            if (idx == TI_LEFT)
            {
                if (pos[0] - dist < -mFieldLength/2.0)
                {
                    new_pos[1] = pos[1] < 0 ? pos[1] + dist : pos[1] - dist;
                } else {
                    new_pos[0] = pos[0] - dist;
                }
            } else {
                if (pos[0] + dist > mFieldLength/2.0)
                {
                    new_pos[1] = pos[1] < 0 ? pos[1] + dist : pos[1] - dist;
                } else {
                    new_pos[0] = pos[0] + dist;
                }
            }
            MoveAgent(agent_aspect, new_pos);
        }
    }
}

void
SoccerRuleAspect::ClearPlayers(const salt::AABB2& box,
                               float min_dist, TTeamIndex idx)
{
    if (idx == TI_NONE || mBallState.get() == 0) return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        ClearPlayer(box, min_dist, *i);
    }
}

void SoccerRuleAspect::ClearPlayer(const salt::AABB2& box, float minDist, std::shared_ptr<AgentState> agentState)
{
    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::GetTransformParent(*agentState, agent_aspect);
    std::shared_ptr<RigidBody> agent_body;
    SoccerBase::GetAgentBody(agent_aspect, agent_body);
    Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
    Vector2f moved_adjustment_xy = Vector2f(moved_adjustment.x(), moved_adjustment.y());
    AABB2 agentAABB2 = SoccerBase::GetAgentBoundingRect(*agent_aspect);
    agentAABB2.Translate(moved_adjustment_xy);

    // if agent is too close, move it away
    Vector3f new_pos = agent_body->GetPosition();
    if (box.Intersects(agentAABB2))
    {
        if (agentState->GetTeamIndex() == TI_LEFT)
        {
            new_pos[0] = box.minVec[0] - minDist;
                //salt::UniformRNG<>(minDist, minDist * 2.0)();
        } else {
            new_pos[0] = box.maxVec[0] + minDist;
                //salt::UniformRNG<>(minDist, minDist * 2.0)();
        }
        MoveAgent(agent_aspect, new_pos);
    }
}

void SoccerRuleAspect::ClearPlayersBeforeKickOff(TTeamIndex idx)
{
    if (mStartAnyFieldPosition || idx == TI_NONE || mBallState.get() == 0) return;

    // move the non-kick off team to own half field except the center
    // circle
    TTeamIndex opp = SoccerBase::OpponentTeam(idx);
    if ( TI_RIGHT == opp ){
        ClearPlayers(mLeftHalf, mFreeKickMoveDist, opp);
    }
    else {
        ClearPlayers(mRightHalf, mFreeKickMoveDist, opp);
    }
    ClearPlayers(Vector3f(0,0,0), mFreeKickDist, mFreeKickMoveDist,opp);

    // move the kick off team to own half field and the center circle
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    salt::AABB2 box;
    if ( TI_RIGHT == idx ){
        box = mLeftHalf;
    }
    else{
        box = mRightHalf;
    }

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;
    float freeKickDist2 = mFreeKickDist*mFreeKickDist;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);
        Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
        Vector2f moved_adjustment_xy = Vector2f(moved_adjustment.x(), moved_adjustment.y());
        AABB2 agentAABB2 = SoccerBase::GetAgentBoundingRect(*agent_aspect);
        agentAABB2.Translate(moved_adjustment_xy);

        // if agent is on opponent half field, move it away
        if (box.Intersects(agentAABB2))
        {
            Vector3f new_pos = agent_body->GetPosition();
            // if agent is in the center circle, do not move it
            if ( agentAABB2.minVec.SquareLength() < freeKickDist2
                 && agentAABB2.maxVec.SquareLength() < freeKickDist2
                 && Vector2f(agentAABB2.minVec.x(),agentAABB2.maxVec.y()).SquareLength() < freeKickDist2
                 && Vector2f(agentAABB2.maxVec.x(),agentAABB2.minVec.y()).SquareLength() < freeKickDist2)
                continue;

            if (idx == TI_LEFT)
            {
                new_pos[0] = box.minVec[0] - mFreeKickMoveDist;
                    //salt::UniformRNG<>(mFreeKickMoveDist, mFreeKickMoveDist * 2.0)();
            } else {
                new_pos[0] = box.maxVec[0] + mFreeKickMoveDist;
                    //salt::UniformRNG<>(mFreeKickMoveDist, mFreeKickMoveDist * 2.0)();
            }
            MoveAgent(agent_aspect, new_pos);
        }
    }
}

void SoccerRuleAspect::ClearPlayersDuringPenaltyShootout()
{
    if (mBallState.get() == 0) return;

    SoccerBase::TAgentStateList agentStates;
    if (!SoccerBase::GetAgentStates(*mBallState.get(), agentStates, TI_NONE))
        return;
    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agentStates.begin(); i != agentStates.end(); ++i)
    {
        bool isGoalie = (*i)->GetUniformNumber() == 1;
        TTeamIndex idx = (*i)->GetTeamIndex();

        if (mGameState->IsPaused() && !isGoalie)
        {
            // Ensure kickers are at least mPenaltyBehindBallDistance meters behind the ball
            // if the game is not running yet.
            if (idx == TI_RIGHT)
            {
                AABB2 adjustedHalf(mLeftHalf.minVec, Vector2f(-mGoalBallLineX + mPenaltyShootoutBallDistance + mPenaltyShootoutBehindBallDistance, mLeftHalf.maxVec.y()));
                ClearPlayer(adjustedHalf, mFreeKickMoveDist, *i);
            }
            else
            {
                AABB2 adjustedHalf(Vector2f(mGoalBallLineX - mPenaltyShootoutBallDistance - mPenaltyShootoutBehindBallDistance, mLeftHalf.minVec.y()), mRightHalf.maxVec);
                ClearPlayer(adjustedHalf, mFreeKickMoveDist, *i);
            }

            // We don't care where the goalies are while the game is paused
        }
        else if (!mGameState->IsPaused()
            && ((isGoalie && idx == mPenaltyShootoutCurrentKickerTeam)
                || (!isGoalie && idx == SoccerBase::OpponentTeam(mPenaltyShootoutCurrentKickerTeam))))
        {
            // Game is running
            // Keep idle players out of the half where the current penalty shootout is taking place
            if (mPenaltyShootoutCurrentKickerTeam == TI_LEFT)
            {
                ClearPlayer(mRightHalf, mFreeKickMoveDist, *i);
            }
            else
            {
                ClearPlayer(mLeftHalf, mFreeKickMoveDist, *i);
            }
        }
    }
}

void
SoccerRuleAspect::RepelPlayers(const salt::Vector3f& pos, float radius,
                               TTeamIndex idx, float pad, bool fAvoidBall)
{
    if (idx == TI_NONE || mBallState.get() == 0) return;

    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);

        // if agent is too close, move it away
        Vector3f new_pos = agent_body->GetPosition();
        float dist = sqrt((new_pos.x()-pos.x())*(new_pos.x()-pos.x()) +
                          (new_pos.y()-pos.y())*(new_pos.y()-pos.y()));
        if (dist < radius)
        {
            Vector2f agent_pos = Vector2f(new_pos.x(),new_pos.y());
            Vector2f avoid_pos = Vector2f(pos.x(),pos.y());
            Vector2f pos2Agent = agent_pos-avoid_pos;
            Vector2f updated_pos = avoid_pos+pos2Agent.Normalize()*(radius+pad);
            new_pos[0] = updated_pos[0];
            new_pos[1] = updated_pos[1];
            MoveAgent(agent_aspect, new_pos, true /*fSafe*/, fAvoidBall);
            //new_pos = GetSafeReposition(new_pos, (*i)->GetUniformNumber(), idx);
            //SoccerBase::MoveAgent(agent_aspect, new_pos);
        }
    }
}

void
SoccerRuleAspect::RepelPlayersForKick(TTeamIndex idx)
{
    if (mRepelPlayersForKick) {
        // Move players taking the kick out of the way of the ball 
        // when it is first placed
        RepelPlayers(mFreeKickPos, mKickRepelDist, idx, false /*fAvoidBall*/);
        mRepelPlayersForKick = false;
    }
}

void
SoccerRuleAspect::SwapTeamSides()
{
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states))
        return;

    mGameState->SwapTeamIndexes();

    SoccerBase::TAgentStateList::iterator it;
    for (it = agent_states.begin(); it != agent_states.end(); ++it)
    {
        (*it)->SetTeamIndex(SoccerBase::OpponentTeam((*it)->GetTeamIndex()));
    }

    // make sure that team names (and probably other things) are updated on
    // monitors
    GetActiveScene()->SetModified(true);
}

void
SoccerRuleAspect::AwardGoalKick(TTeamIndex idx)
{
    if (mPenaltyShootout)
    {
        // No goal kick here
        mGameState->SetPlayMode(PM_BeforeKickOff);
        return;
    }

    if (idx == TI_LEFT)
        {
            mFreeKickPos[0] = -mFieldLength / 2 + mGoalKickDist;
            mFreeKickPos[1] = 0.0;
            mFreeKickPos[2] = mBallRadius;
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode(PM_GOAL_KICK_LEFT);
        }
    else if (idx == TI_RIGHT)
        {
            mFreeKickPos[0] = mFieldLength / 2 - mGoalKickDist;
            mFreeKickPos[1] = 0.0;
            mFreeKickPos[2] = mBallRadius;
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode(PM_GOAL_KICK_RIGHT);
        }
    else {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) " << "invalid team index for awarding goal kick\n";
    }
}

void
SoccerRuleAspect::AwardCornerKick(TTeamIndex idx)
{
    if (mPenaltyShootout)
    {
        // No corner kick here
        mGameState->SetPlayMode(PM_BeforeKickOff);
        return;
    }

    Vector3f ball_pos = mBallBody->GetPosition();
    if (idx == TI_LEFT)
        {
            // temp value for RoboCup 2012
            // correct value: mFieldWidth / 2 - mBallRadius
            const float cornerKickY = (mFieldWidth + mGoalWidth) / 4.0
                - mBallRadius;
            mFreeKickPos[0] = mFieldLength / 2 - mBallRadius;
            mFreeKickPos[1] = ball_pos[1] > 0 ?
                cornerKickY : -cornerKickY;
            mFreeKickPos[2] = mBallRadius;
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode(PM_CORNER_KICK_LEFT);
            
        }
    else if (idx == TI_RIGHT)
        {
            // temp value for RoboCup 2012
            // correct value: mFieldWidth / 2 - mBallRadius
            const float cornerKickY = (mFieldWidth + mGoalWidth) / 4.0
                - mBallRadius;
            mFreeKickPos[0] = -mFieldLength / 2 + mBallRadius;
            mFreeKickPos[1] = ball_pos[1] > 0 ?
                cornerKickY : -cornerKickY;
            mFreeKickPos[2] = mBallRadius;
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode(PM_CORNER_KICK_RIGHT);
        }
    else {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) " << "invalid team index for awarding corner kick\n";
    }
}

void
SoccerRuleAspect::AwardKickIn(TTeamIndex idx)
{
    if (mPenaltyShootout)
    {
        // No kick in kick here
        mGameState->SetPlayMode(PM_BeforeKickOff);
        return;
    }

    if (idx == TI_LEFT || idx == TI_RIGHT)
        {
            mFreeKickPos = mBallState->GetLastValidBallPosition();
            mFreeKickPos[1] = mFreeKickPos[1] > 0 ?
                mFieldWidth / 2 - mBallRadius : -mFieldWidth / 2 + mBallRadius;
            mFreeKickPos[2] = mBallRadius;
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode((idx == TI_LEFT) ?
                                    PM_KickIn_Left : PM_KickIn_Right);
        }
    else {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) " << "invalid team index for awarding kick in\n";
    }
}

void
SoccerRuleAspect::AwardFreeKick(TTeamIndex idx, bool indirect)
{
    if (mPenaltyShootout)
    {
        // No free kick here
        mGameState->SetPlayMode(PM_BeforeKickOff);
        return;
    }

    if (idx == TI_LEFT || idx == TI_RIGHT)
        {
            mRepelPlayersForKick = true;
            mGameState->SetPlayMode((idx == TI_LEFT) ?
                                    (indirect ? PM_FREE_KICK_LEFT : 
                                     PM_DIRECT_FREE_KICK_LEFT) :
                                    (indirect ? PM_FREE_KICK_RIGHT : 
                                     PM_DIRECT_FREE_KICK_RIGHT));
        }
    else {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) " << "invalid team index for awarding free kick\n";
    }
}

void
SoccerRuleAspect::StartPassMode(TTeamIndex idx)
{
    passModeBallPos[idx] = mBallBody->GetPosition();

    mGameState->SetPlayMode(idx == TI_LEFT ? PM_PASS_LEFT : PM_PASS_RIGHT);
}

void
SoccerRuleAspect::PunishIndirectKickGoal(
    std::shared_ptr<oxygen::AgentAspect> agent, 
    TTeamIndex scoredOnTeamIdx)
{
    std::shared_ptr<AgentState> agentState;
    if (!SoccerBase::GetAgentState(agent, agentState))
    {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
    }
    else
    {
        mIndirectKick = false;
        if (agentState->GetTeamIndex() == scoredOnTeamIdx) 
        {
            // We have an own goal on an indirect kick so award opponent a corner kick
            TTeamIndex opp = SoccerBase::OpponentTeam(agentState->GetTeamIndex());
            AwardCornerKick(opp);
        } else {
            // Award team who was scored on during indirect kick a goal kick
            AwardGoalKick(scoredOnTeamIdx);  
        }
    }
}

void
SoccerRuleAspect::PunishFreeKickFoul(
    std::shared_ptr<oxygen::AgentAspect> agent)
{
    std::shared_ptr<AgentState> agentState;
    if (!SoccerBase::GetAgentState(agent, agentState))
    {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
    }
    else
    {
        // Award the opponent team a free kick
        TTeamIndex opp = SoccerBase::OpponentTeam(agentState->GetTeamIndex());
        AwardFreeKick(opp, true);
    }
}

inline bool SoccerRuleAspect::WasLastKickFromFreeKick(
    std::shared_ptr<oxygen::AgentAspect> &lastKicker)
{
    TTime kickTime;
    // notice that a kick is not necessarily an immediate action, it can
    // take some time...
    if (!mLastFreeKickTaker || !mBallState->GetLastCollidingAgent(lastKicker, kickTime)) {
        return false;
    }

    std::shared_ptr<AgentState> agentStateLastKicker;
    if (!SoccerBase::GetAgentState(lastKicker, agentStateLastKicker))
    {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
        return false;
    }

    std::shared_ptr<AgentState> agentStateLastFreeKickTaker;
    if (!SoccerBase::GetAgentState(mLastFreeKickTaker, agentStateLastFreeKickTaker))
    {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
        return false;
    }
    
    return kickTime - mLastFreeKickKickTime < 0.1 // kick duration = 0.1
            && agentStateLastKicker->GetUniformNumber() == agentStateLastFreeKickTaker->GetUniformNumber()
            && agentStateLastKicker->GetTeamIndex() == agentStateLastFreeKickTaker->GetTeamIndex();
}

void
SoccerRuleAspect::ClearSelectedPlayers()
{
    float min_dist = mFreeKickMoveDist;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, TI_NONE))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        SoccerBase::GetTransformParent(**i, agent_aspect);

        // if agent is selected, move it away
        Vector3f new_pos = agent_aspect->GetWorldTransform().Pos();

        if ((*i)->IsSelected())
        {
            float dist = min_dist; //salt::UniformRNG<>(min_dist, min_dist + 2.0)();

            if ((*i)->GetTeamIndex() == TI_LEFT)
            {
                if (new_pos[0] - dist < -mFieldLength/2.0)
                {
                    new_pos[1] = new_pos[1] < 0 ? new_pos[1] + dist : new_pos[1] - dist;
                } else {
                    new_pos[0] = new_pos[0] - dist;
                }
            } else {
                if (new_pos[0] + dist > mFieldLength/2.0)
                {
                    new_pos[1] = new_pos[1] < 0 ? new_pos[1] + dist : new_pos[1] - dist;
                } else {
                    new_pos[0] = new_pos[0] + dist;
                }
            }
            MoveAgent(agent_aspect, new_pos);
        }
    }
}

vector<SoccerRuleAspect::Foul>
SoccerRuleAspect::GetFouls() const
{
    return mFouls;
}

vector<SoccerRuleAspect::Foul>
SoccerRuleAspect::GetFoulsSince(unsigned index) const
{
    Foul f(index+1, (EFoulType)0, std::shared_ptr<AgentState>());
    vector<SoccerRuleAspect::Foul>::const_iterator low = lower_bound(mFouls.begin(), mFouls.end(), f);
    return vector<Foul>(low, mFouls.end());
}

void
SoccerRuleAspect::DropBall()
{
    DropBall(mBallBody->GetPosition());
}

void
SoccerRuleAspect::DropBall(Vector3f pos)
{
    salt::Vector2f ball_pos(pos.x(), pos.y());

    // we do not drop the ball within the penalty area
    if (mLeftPenaltyArea.Contains(ball_pos))
    {
        pos[0] = mLeftPenaltyArea.maxVec[0];
        pos[1] = pos.y() < 0 ?
            mLeftPenaltyArea.minVec[1] : mLeftPenaltyArea.maxVec[1];
    }
    else if (mRightPenaltyArea.Contains(ball_pos))
    {
        pos[0] = mRightPenaltyArea.minVec[0];
        pos[1] = pos.y() < 0 ?
            mRightPenaltyArea.minVec[1] : mRightPenaltyArea.maxVec[1];
    }

    // do not drop the ball outside the field
    if (pos.y() <= -mFieldWidth / 2)
    {
        pos.y() = -mFieldWidth / 2 + mBallRadius;
    }
    else if (pos.y() >= mFieldWidth / 2)
    {
        pos.y() = mFieldWidth / 2 - mBallRadius;
    }

    MoveBall(pos);

    if (rand()%2 == 0) 
    {
        ClearPlayers(pos, mFreeKickDist, mFreeKickMoveDist, TI_LEFT);
        ClearPlayers(pos, mFreeKickDist, mFreeKickMoveDist, TI_RIGHT);
    } 
    else 
    {
        ClearPlayers(pos, mFreeKickDist, mFreeKickMoveDist, TI_RIGHT);
        ClearPlayers(pos, mFreeKickDist, mFreeKickMoveDist, TI_LEFT);
    }
    
    // After a drop ball allow anyone to touch it
    ResetKickChecks();
 
    mGameState->SetPlayMode(PM_PlayOn);
}

void
SoccerRuleAspect::UpdateBeforeKickOff()
{
    // get game control server to check agent count
    std::shared_ptr<GameControlServer> game_control;

    if (!SoccerBase::GetGameControlServer(*this, game_control))
    {
        return;
    }

    // if no players are connected, just return
    if (! game_control->GetAgentCount()) return;


    // before the game starts the ball should stay in the middle of
    // the playing field
    Vector3f pos(0,0,mBallRadius);
    MoveBall(pos);

    mGameState->SetPaused(true);
    
    if (!mStartAnyFieldPosition && !mPenaltyShootout)
    {
        if (rand()%2 == 0) 
        {
            ClearPlayers(mRightHalf, mFreeKickMoveDist, TI_LEFT);
            ClearPlayers(mLeftHalf, mFreeKickMoveDist, TI_RIGHT);
        } 
        else 
        {
            ClearPlayers(mLeftHalf, mFreeKickMoveDist, TI_RIGHT);
            ClearPlayers(mRightHalf, mFreeKickMoveDist, TI_LEFT);
        }
    }
    else if (mPenaltyShootout)
    {
        ClearPlayersDuringPenaltyShootout();
    }

    if (mPenaltyShootoutBallPlaced)
    {
        // The shot was just terminated and the player didn't score a goal
        mGameState->PenaltyShootoutShotExecuted();
    }
    mPenaltyShootoutBallPlaced = false;
    mPenaltyShootoutBallTouchOver = false;

#if 0
    //
    // TODO: this has to be tested (compiles and no crashes at least)
    mInOffsideLeftPlayers.clear();
    mInOffsideRightPlayers.clear();
#endif

    float kickOffWaitTime = 0;
    if (mAutoKickOffTimeOrigin > mGameState->GetModeTime())
        mAutoKickOffTimeOrigin = mGameState->GetModeTime();
    else
        kickOffWaitTime = mGameState->GetModeTime() - mAutoKickOffTimeOrigin;

    if (mAutomaticKickOff && kickOffWaitTime > mWaitBeforeKickOff && mPenaltyShootoutCurrentKickerTeam == TI_NONE)
    {
        // Automatic kick-off (for penalty shootout: this only affects the initial shot)
        mGameState->KickOff();
    }
    else if (mPenaltyShootout && mGameState->GetModeTime() >= mGoalPauseTime && mPenaltyShootoutCurrentKickerTeam != TI_NONE)
    {
        // Automatic kick-off in penalties if this is not the first shot
        mGameState->KickOff(SoccerBase::OpponentTeam(mPenaltyShootoutCurrentKickerTeam));
    }
}

void
SoccerRuleAspect::UpdateKickOff(TTeamIndex idx)
{
    mGameState->SetPaused(false);

    if (mPenaltyShootout)
    {
        mPenaltyShootoutCurrentKickerTeam = idx;
    }

    ResetKickChecks();
    mAllowKickOffTeamToScore = true;

    if (mPenaltyShootout)
    {
        ClearPlayersDuringPenaltyShootout();
    }
    else
    {
        ClearPlayersBeforeKickOff(idx);
    }

    if (mPenaltyShootout && !mPenaltyShootoutBallPlaced) {
        Vector3f pos(0, 0, mBallRadius);
        // Move the ball into the appropriate half
        if (mPenaltyShootoutCurrentKickerTeam == TI_LEFT)
        {
            // Left team is next
            pos = Vector3f(mGoalBallLineX - mPenaltyShootoutBallDistance, 0, mBallRadius);
        }
        else if (mPenaltyShootoutCurrentKickerTeam == TI_RIGHT)
        {
            // Right team is next
            pos = Vector3f(-mGoalBallLineX + mPenaltyShootoutBallDistance, 0, mBallRadius);
        }
        MoveBall(pos);
        mPenaltyShootoutBallPlaced = true;

        // Count the time for scoring a goal from here on
        mPenaltyShootoutStart = mGameState->GetTime();
    }

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    // This does not apply to penalty shootout
    if (mDropBallTime > 0 && !mPenaltyShootout &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        // Drop the ball at its current position.
        // This should always be (0,0) during kickoff.
        DropBall(mBallBody->GetPosition());
        return;
    }

    if (mPenaltyShootout && mPenaltyShootoutMaxTime > 0.0 && (mGameState->GetTime() - mPenaltyShootoutStart) > mPenaltyShootoutMaxTime)
    {
        // During penalty shootouts: after mPenaltyShootoutTime, it's the other teams turn.
        // The player didn't touch the ball yet.
        mGameState->SetPlayMode(PM_BeforeKickOff);
        return;
    }

    // after the first agent touches the ball move to PM_PLAYON
    std::shared_ptr<AgentAspect> agent;
    TTime time;
    if (! mBallState->GetLastCollidingAgent(agent,time))
    {
        return;
    }
    if (time > mGameState->GetLastModeChange())
    {
        std::shared_ptr<GameControlServer> game_control;
        if (SoccerBase::GetGameControlServer(*this, game_control)
            && !mPenaltyShootout)
        {
            SetKickTakenValues(time, agent, true);
            mLastKickOffTaker = agent;
            mAllowKickOffTeamToScore = false;
        }
        mGameState->SetPlayMode(PM_PlayOn);
    }
}

void
SoccerRuleAspect::UpdateKickIn(TTeamIndex idx)
{
    // [patmac] This method is almost identical to UpdateFreeKick
    // and could probably just call UpdateFreeKick(idx, true /*indirect*/)

    mGameState->SetPaused(false);

    // do nothing for the duration of mKickInPauseTime
    if (mGameState->GetModeTime() < mKickInPauseTime)
    {
        //mGameState->SetPaused(true);
        mRepelPlayersForKick = true;
        return;
    }

    ResetKickChecks();

    // move away opponent team
    ClearPlayers(mFreeKickPos, mFreeKickDist, mFreeKickMoveDist,
                 SoccerBase::OpponentTeam(idx));

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    if (mDropBallTime > 0 &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        DropBall(mFreeKickPos);
        return;
    }

    // after the first agent touches the ball move to PM_PLAY_ON. the
    // time when the agent last touches the ball must be after the
    // change to the KickIn mode *plus* pause time
    std::shared_ptr<AgentAspect> agent;
    TTime time;
    bool fHaveAgentCollidedWithBall = mBallState->GetLastCollidingAgent(agent,time); 

    TTime lastChange = mGameState->GetLastModeChange();
    if (fHaveAgentCollidedWithBall && time > lastChange + mKickInPauseTime + 0.03 && !mRepelPlayersForKick)
    {
        SetKickTakenValues(time, agent, true);
        mGameState->SetPlayMode(PM_PlayOn);
    } else
    {
        RepelPlayersForKick(idx);

        // move the ball back on the ground where it left the playing
        // field
        MoveBall(mFreeKickPos);
    }
}


//-----------------------------------


void
SoccerRuleAspect::UpdateFreeKick(TTeamIndex idx, bool indirect)
{
    mGameState->SetPaused(false);

    // do nothing for the duration of mKickInPauseTime
    if (mGameState->GetModeTime() < mKickInPauseTime)
    {
        //mGameState->SetPaused(true);
        mRepelPlayersForKick = true;
        return;
    }
//---------------

    ResetKickChecks();
    
    salt::Vector2f ball_pos(mFreeKickPos.x(), mFreeKickPos.y());
    // we do not drop the ball within the penalty area
    if (mLeftPenaltyArea.Contains(ball_pos))
    {
        mFreeKickPos[0] = mLeftPenaltyArea.maxVec[0];
        mFreeKickPos[1] = mFreeKickPos.y() < 0 ?
            mLeftPenaltyArea.minVec[1] : mLeftPenaltyArea.maxVec[1];
    }
    else if (mRightPenaltyArea.Contains(ball_pos))
    {
        mFreeKickPos[0] = mRightPenaltyArea.minVec[0];
        mFreeKickPos[1] = mFreeKickPos.y() < 0 ?
            mRightPenaltyArea.minVec[1] : mRightPenaltyArea.maxVec[1];
    }

//--------------------------

    // move away opponent team

    ClearPlayers(mFreeKickPos, mFreeKickDist, mFreeKickMoveDist,
                 SoccerBase::OpponentTeam(idx));

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    if (mDropBallTime > 0 &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        DropBall(mFreeKickPos);
        return;
    }

    // after the first agent touches the ball move to PM_PLAY_ON. the
    // time when the agent last touches the ball must be after the
    // change to the KickIn mode
    std::shared_ptr<AgentAspect> agent;
    TTime time;
    bool fHaveAgentCollidedWithBall = mBallState->GetLastCollidingAgent(agent,time);

    TTime lastChange = mGameState->GetLastModeChange();
    if (fHaveAgentCollidedWithBall && time > lastChange + mKickInPauseTime + 0.03 && !mRepelPlayersForKick)
    {
        SetKickTakenValues(time, agent, indirect);
        mGameState->SetPlayMode(PM_PlayOn);
        //GetLog()->Error() << "ERROR: (SoccerRuleAspect) " << "Set Playmode to playon\n";
    } else
    {
        RepelPlayersForKick(idx);
 
        // move the ball back on the ground where it left the playing
        // field
        MoveBall(mFreeKickPos);
    }
}

//-----------------------------------



void
SoccerRuleAspect::UpdateGoalKick(TTeamIndex idx)
{
    mGameState->SetPaused(false);

    // do nothing for the duration of mKickInPauseTime
    if (mGameState->GetModeTime() < mKickInPauseTime)
    {
        //mGameState->SetPaused(true);
        mRepelPlayersForKick = true;
        return;
    }

    ResetKickChecks();

    // move away opponent team
    ClearPlayers(idx == TI_LEFT ? mLeftPenaltyArea : mRightPenaltyArea,
                 mFreeKickMoveDist, SoccerBase::OpponentTeam(idx));

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    if (mDropBallTime > 0 &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        DropBall(mFreeKickPos);
        return;
    }

    // after the first agent touches the ball, we do nothing until
    // the ball leaves the penalty area.
    std::shared_ptr<AgentAspect> agent;
    TTime time;
    if (! mBallState->GetLastCollidingAgent(agent,time))
    {
        return;
    }

    TTime lastChange = mGameState->GetLastModeChange();
    // if the team with the goal kick touched the ball and the ball is
    // outside the penalty area, we switch to play on.
    if (time > lastChange + mKickInPauseTime + 0.03 && !mRepelPlayersForKick)
    {
        Vector2f pos(mBallBody->GetPosition().x(),
                     mBallBody->GetPosition().y());
        if ((idx == TI_RIGHT && !mRightPenaltyArea.Contains(pos)) ||
            (idx == TI_LEFT && !mLeftPenaltyArea.Contains(pos)) ||
            (idx == TI_NONE))
        {
            // Additional check that we don't have ball sitting on endline
            // of goal box and accidentally think that the ball has left the
            // goal box but is still in bounds
            if (!mBallState->GetBallOnField() ||
                (idx == TI_RIGHT && (pos.x() < mRightPenaltyArea.minVec[0] || pos.y() < mRightPenaltyArea.minVec[1] || pos.y() > mRightPenaltyArea.maxVec[1])) ||
                (idx == TI_LEFT && (pos.x() > mLeftPenaltyArea.maxVec[0] || pos.y() < mLeftPenaltyArea.minVec[1] || pos.y() > mLeftPenaltyArea.maxVec[1])) ||
                (idx == TI_NONE))
            {
                SetKickTakenValues(time, agent, false);
                mGameState->SetPlayMode(PM_PlayOn);
            }
        }
        return;
    }
    // the ball was not touched yet
    else
    {
        RepelPlayersForKick(idx);
        
        // move the ball back on the free kick position
        MoveBall(mFreeKickPos);
    }
}

void
SoccerRuleAspect::UpdateCornerKick(TTeamIndex idx)
{
    mGameState->SetPaused(false);

    // do nothing for the duration of mKickInPauseTime
    if (mGameState->GetModeTime() < mKickInPauseTime)
    {
        //mGameState->SetPaused(true);
        mRepelPlayersForKick = true;
        return;
    }

    ResetKickChecks();

    // move away opponent team
    ClearPlayers(mFreeKickPos, mFreeKickDist, mFreeKickMoveDist,
                 SoccerBase::OpponentTeam(idx));

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    if (mDropBallTime > 0 &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        DropBall(mFreeKickPos);
        return;
    }

    // after the first agent touches the ball move to PM_PLAY_ON. the
    // time when the agent last touches the ball must be after the
    // change to the KickIn mode *plus* pause time
    std::shared_ptr<AgentAspect> agent;
    TTime time;
    if (! mBallState->GetLastCollidingAgent(agent,time))
    {
        return;
    }

    TTime lastChange = mGameState->GetLastModeChange();
    if (time > lastChange + mKickInPauseTime + 0.03 && !mRepelPlayersForKick)
    {
        SetKickTakenValues(time, agent, false);
        mGameState->SetPlayMode(PM_PlayOn);
    } else
    {
        RepelPlayersForKick(idx);
        
        // move the ball back on the ground where it left the playing
        // field
        MoveBall(mFreeKickPos);
    }
}

void
SoccerRuleAspect::UpdatePassMode(TTeamIndex idx)
{
    mGameState->SetPaused(false);

    mGameState->SetLastTimeInPassMode(idx, mGameState->GetTime());
    playerUNumTouchedBallSincePassMode[idx] = -1;
    mulitpleTeammatesTouchedBallSincePassMode[idx] = false;
    ballLeftPassModeCircle[idx] = false;
    mGameState->SetPassModeClearedToScore(idx, false);

    // Cancel out affects of pass mode for opponent
    mGameState->SetLastTimeInPassMode(SoccerBase::OpponentTeam(idx), -1000);

    std::shared_ptr<AgentAspect> agent;
    TTime time;

    if (mGameState->GetModeTime() >= mPassModeDuration) { 
        mGameState->SetPlayMode(PM_PlayOn);
    }
    else if (mBallState->GetLastCollidingAgent(agent,time))
    {
        TTime lastChange = mGameState->GetLastModeChange();
        if (time >= lastChange) { 
            mGameState->SetPlayMode(PM_PlayOn);
        }
    }

    UpdatePlayOn();

    if (mGameState->GetPlayMode() == (idx == TI_LEFT ? PM_PASS_LEFT : PM_PASS_RIGHT)) {
        passModeBallPos[idx] = mBallBody->GetPosition();

        // keep away opponent team from ball
        RepelPlayers(mBallBody->GetPosition(), mPassModeMinOppBallDist, SoccerBase::OpponentTeam(idx), 0.1);
    }
}
    

bool
SoccerRuleAspect::CheckBallLeftField()
{
//     cerr << "CheckBallLeftField\n";
    if (mBallState->GetBallOnField())
    {
        // update freekickpos
        mFreeKickPos = mBallState->GetLastValidBallPosition();
        mFreeKickPos[2] = mBallRadius;

        return false;
    }

    // get the team of the last agent touching the ball and set the
    // correct kick in playmode
    std::shared_ptr<AgentAspect> agent;
    std::shared_ptr<AgentState> agentState;
    TTime time;

    if (mBallState->GetLastCollidingAgent(agent,time) &&
        SoccerBase::GetAgentState(agent,agentState))
    {
        /* Possibilities are:
           - Ball left field on the long sides: kick in for the other team
           - Ball left field on the short sides:
             - corner kick if the a team kicked the ball over its own side
             - goal kick if the a team kicked the ball over opponent side
           - [ The ball left the field through a hole in the floor or ceiling
               or some aliens have taken it away =:-]
               In this case put the ball back to the last valid position and
               we hope nobody sees.
               (this should not happen. really.  But it CAN happen depending
               on the ODE parameters you choose or if somebody is going to
               simulate the first contact (stardate 50893.5)).
        */
        Vector3f ball_pos = mBallBody->GetPosition();
        bool last_touch_left = (agentState->GetTeamIndex() == TI_LEFT);
        bool ball_left = (ball_pos[0] < 0);
        //bool ball_up = (ball_pos[1] < 0);

        // handle corner / goal kick
        if (salt::gAbs(ball_pos.x()) >= mFieldLength / 2)
        {
            // check goal kick right team
            if (last_touch_left && !ball_left)
            {
                AwardGoalKick(TI_RIGHT);
            }
            // check goal kick left team
            else if (!last_touch_left && ball_left)
            {
                AwardGoalKick(TI_LEFT);
            }
            // check corner kick right team
            else if (last_touch_left && ball_left)
            {
                AwardCornerKick(TI_RIGHT);
            }
            // check corner kick left team
            else
            {
                AwardCornerKick(TI_LEFT);
            }
        }
        // handle kick in
        else if (salt::gAbs(ball_pos.y()) >= mFieldWidth / 2)
        {
            // Award the opponent team a kick in
            TTeamIndex opp = SoccerBase::OpponentTeam(agentState->GetTeamIndex());
            AwardKickIn(opp);
        }
        // we've got a situation here
        else {
            // this will stop the ball, but better than losing it away.
            MoveBall(mBallState->GetLastValidBallPosition());
            // no need to change the game state, we just don't know what
            // has been going on.
            return false;
        }
    }

    return true;
}

bool
SoccerRuleAspect::CheckGoal()
{
    // check if the ball is in one of the goals
    TTeamIndex idx = mBallState->GetGoalState();

    if (idx == TI_NONE)
    {
        // sometimes, ball can't record goals due to approximation errors,
        // so we check for goals analytically
        const salt::Vector3f ballPos = mBallBody->GetPosition();
        const float xDist2Goal = fabs(ballPos.x()) - mGoalBallLineX;

        // check if ball is completely out of the field
        if (xDist2Goal < 0)
            return false;

        salt::Vector3f normBVel = mBallBody->GetVelocity();
        // ball should be inside the field recently (assumes that the simulation
        // step size is smaller than 1 second)
        if (fabs(ballPos.x() - normBVel.x()) > mGoalBallLineX)
            return false;

        normBVel.Normalize();
        float velCos = normBVel.x();
        float dist = xDist2Goal / velCos;
        salt::Vector3f crossPoint = ballPos - normBVel * dist;

        if (fabs(crossPoint.y()) < mGoalWidth / 2.0 &&
                crossPoint.z() < mGoalHeight)
        {
            if (ballPos.x() < 0)
                idx = TI_LEFT;
            else
                idx = TI_RIGHT;
        }
        else
            return false;
    }
    
    /* Don't allow goals kicked from inside center circle directly after 
       kickoff
     */
    if (!mAllowKickOffTeamToScore) {
         std::shared_ptr<AgentState> agentState;
         if (!SoccerBase::GetAgentState(mLastKickOffTaker, agentState))
             {
                 GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot"
                     " get AgentState from an AgentAspect\n";
             }
         else {
             TTeamIndex team = agentState->GetTeamIndex();
             if (idx != team) {
                 // Team that scored is same team that took kickoff
                 PunishIndirectKickGoal(mLastKickOffTaker, idx);
                 // Return true so that we know the ball is in the goal and 
                 // don't check for other conditions such as the ball being out
                 // of bounds
                 return true;
             }
         }
    }

    /* don't allow goals directly from kickoff (penalty shot kickoffs are 
     * direct)
     *
     * todo it is allowed in FIFA rules, so we should get rid of it e.g. by
     * adding noise to the beam effector so that kickoff kicks cannot be
     * precisely planned
     */
    std::shared_ptr<AgentAspect> agent;
    std::shared_ptr<GameControlServer> game_control;
    // Don't allow goals off indirect kicks or own goals off direct kicks
    if (WasLastKickFromFreeKick(agent)) {
        std::shared_ptr<AgentState> agentState;
        if (!SoccerBase::GetAgentState(agent, agentState))
             {
                 GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot"
                     " get AgentState from an AgentAspect\n";
             }
        else if ((mIndirectKick || agentState->GetTeamIndex() == idx)
            && SoccerBase::GetGameControlServer(*this, game_control)
            && !mPenaltyShootout) 
            {
                PunishIndirectKickGoal(agent, idx);
                // Return true so that we know the ball is in the goal and don't
                // check for other conditions such as the ball being out of 
                // bounds
                return true;
            }
    }

    // Check that a team hasn't scored out of pass mode
    if (mGameState->GetTime()-mGameState->GetLastTimeInPassMode(SoccerBase::OpponentTeam(idx)) < mPassModeScoreWaitTime 
        && !mGameState->GetPassModeClearedToScore(SoccerBase::OpponentTeam(idx))) {
        AwardGoalKick(idx);
        // Return true so that we know the ball is in the goal and don't
        // check for other conditions such as the ball being out of 
        // bounds
        return true;
    }

    // score the lucky team if no goal was awarded yet
    if (!mGoalAwarded)
    {
        mGameState->ScoreTeam((idx == TI_LEFT) ? TI_RIGHT : TI_LEFT);
        mGameState->SetPlayMode((idx == TI_LEFT) ? PM_Goal_Right : PM_Goal_Left);
        mGoalAwarded = true;
    }

    return true;
}

void
SoccerRuleAspect::ResetKickChecks()
{
    mCheckFreeKickKickerFoul = false;
    mIndirectKick = false;
    
    if (mGameState.get()) {
        mGameState->SetLastTimeInPassMode(TI_LEFT, -1000);
        mGameState->SetLastTimeInPassMode(TI_RIGHT, -1000);
    }
}

void
SoccerRuleAspect::SetKickTakenValues(TTime time,  
                                     std::shared_ptr<oxygen::AgentAspect> agent, 
                                     bool indirect)
{
    mCheckFreeKickKickerFoul = true;
    mLastFreeKickKickTime = time;
    mLastFreeKickTaker = agent;
    mIndirectKick = indirect;
}

bool
SoccerRuleAspect::CheckFreeKickTakerFoul()
{
    if (!mCheckFreeKickKickerFoul || !mLastFreeKickTaker)
        return false;

    std::shared_ptr<AgentAspect> agent;
    if (!WasLastKickFromFreeKick(agent)) // second kick
    {
        mCheckFreeKickKickerFoul = false;
        mIndirectKick = false;

        std::shared_ptr<AgentState> agentStateLastKicker;
        if (!SoccerBase::GetAgentState(agent, agentStateLastKicker))
        {
            GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
            return false;
        }

        std::shared_ptr<AgentState> agentStateLastFreeKickTaker;
        if (!SoccerBase::GetAgentState(mLastFreeKickTaker, agentStateLastFreeKickTaker))
        {
            GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                "AgentState from an AgentAspect\n";
            return false;
        }

        if (agentStateLastKicker->GetUniformNumber() == agentStateLastFreeKickTaker->GetUniformNumber()
            && agentStateLastKicker->GetTeamIndex() == agentStateLastFreeKickTaker->GetTeamIndex())
        {
            PunishFreeKickFoul(mLastFreeKickTaker);
            return true;
        }
    }
    return false;
}

void
SoccerRuleAspect::UpdatePassModeScoringCheckValues()
{
    TTeamIndex passModeTeam = TI_NONE;
    if (mGameState->GetTime() - mGameState->GetLastTimeInPassMode(TI_LEFT) < mPassModeScoreWaitTime && !mGameState->GetPassModeClearedToScore(TI_LEFT)) {
        passModeTeam = TI_LEFT;
    } else if (mGameState->GetTime() - mGameState->GetLastTimeInPassMode(TI_RIGHT) < mPassModeScoreWaitTime && !mGameState->GetPassModeClearedToScore(TI_RIGHT)) {
        passModeTeam = TI_RIGHT;
    }

    if (passModeTeam != TI_NONE) {
        if (!ballLeftPassModeCircle[passModeTeam]) {
            // Check if ball has left original pass mode circle
            Vector3f ball_pos = mBallBody->GetPosition();
            Vector3f pm_ball_pos = passModeBallPos[passModeTeam];
            float dist = sqrt((ball_pos.x()-pm_ball_pos.x())*(ball_pos.x()-pm_ball_pos.x()) +
                          (ball_pos.y()-pm_ball_pos.y())*(ball_pos.y()-pm_ball_pos.y()));
            if (dist >= mPassModeMinOppBallDist) {
                ballLeftPassModeCircle[passModeTeam] = true;
            }
        }

        list<std::shared_ptr<AgentAspect> > agents;
        if (mBallState->GetCollidingAgents(agents)) {
            for (list<std::shared_ptr<AgentAspect> > ::const_iterator agentIt = agents.begin();
                 agentIt != agents.end();
                agentIt++) 
            {
                std::shared_ptr<AgentState> agentState;
                if (!SoccerBase::GetAgentState(*agentIt, agentState))
                {
                    GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
                    "AgentState from an AgentAspect\n";
                }
                else
                {
                    int unum = agentState->GetUniformNumber();
                    int idx = agentState->GetTeamIndex();
                    if (idx == passModeTeam) {
                        if (playerUNumTouchedBallSincePassMode[passModeTeam] > 0 
                            && (playerUNumTouchedBallSincePassMode[passModeTeam] != unum
                                || mulitpleTeammatesTouchedBallSincePassMode[passModeTeam])) {
                            mulitpleTeammatesTouchedBallSincePassMode[passModeTeam] = true;
                            if (ballLeftPassModeCircle[passModeTeam]) {
                                GetLog()->Error() << "Pass mode for " << (passModeTeam == TI_LEFT ? "left" : "right") << " team cleared to score.\n";
                                mGameState->SetPassModeClearedToScore(passModeTeam, true);
                            }
                            break;
                        } else {
                            playerUNumTouchedBallSincePassMode[passModeTeam] = unum;
                        }   
                    }
                }
            }
        }
    }
}

void
SoccerRuleAspect::UpdatePlayOn()
{
    mGameState->SetPaused(false);

    if (mPenaltyShootout)
    {
        ClearPlayersDuringPenaltyShootout();

        std::shared_ptr<AgentAspect> collidingAgent;
        TTime kickTime;
        mBallState->GetLastCollidingAgent(collidingAgent, kickTime);
        TTime timeSinceLastBallTouch = mGameState->GetTime() - kickTime;
        if (!mPenaltyShootoutBallTouchOver)
        {
            mPenaltyShootoutKicker = collidingAgent;
        }
        if (timeSinceLastBallTouch > 0.0)
        {
            mPenaltyShootoutBallTouchOver = true;
        }

        if ((mPenaltyShootoutMaxTime > 0.0 && (mGameState->GetTime() - mPenaltyShootoutStart) > mPenaltyShootoutMaxTime)
            || (mGameState->GetModeTime() > 0.5 && mBallBody->GetVelocity().Length() < 0.002)
            || (timeSinceLastBallTouch == 0.0 && mPenaltyShootoutBallTouchOver && collidingAgent == mPenaltyShootoutKicker))
        {
            // The agent didn't score a goal. Shot can be terminated.
            // Reasons:
            // * After mPenaltyShootoutTime, it's the other teams turn.
            // * If the ball is not moving anymore, there's nothing we need to wait for.
            //   The agent has half a second to accelerate the ball.
            // * The agent touched the ball a second time.
            mGameState->SetPlayMode(PM_BeforeKickOff);
            return;
        }
    }

    UpdatePassModeScoringCheckValues();

    // check that player who took free kick doesn't touch the ball a second
    // time before another agent touches the ball
    if (CheckFreeKickTakerFoul())
    {
        return;
    }

    // check if the ball is in one of the goals
    if (CheckGoal())
    {
        return;
    }

    // check if the ball is otherwise not on the playing field
    if (CheckBallLeftField())
    {
        return;
    }

#if 0
    // check if the players are in offside
    if (mUseOffside && CheckOffside())
    {
        return;
    }
#endif

    // other checks go here...
}

void
SoccerRuleAspect::UpdateGoal()
{
    mGameState->SetPaused(true);

    if (mPenaltyShootoutBallPlaced)
    {
        // A penalty shot just ended successfully
        mGameState->PenaltyShootoutShotExecuted();
    }
    mPenaltyShootoutBallPlaced = false;
    mPenaltyShootoutBallTouchOver = false;

    // check if the pause time after the goal has elapsed
    if (mGameState->GetModeTime() < mGoalPauseTime)
    {
        return;
    }

    // put the ball back in the middle of the playing field
    Vector3f pos(0, 0, mBallRadius);
    MoveBall(pos);

    // kick off for the opposite team
    // Original
//     mGameState->SetPlayMode(
//         mGameState->GetPlayMode() == PM_Goal_Left ?
//         PM_KickOff_Right : PM_KickOff_Left
//         );

    // kick off for the opposite team
    mGameState->KickOff(
        mGameState->GetPlayMode() == PM_Goal_Left ?
        TI_RIGHT : TI_LEFT
        );
}

void
SoccerRuleAspect::UpdateGameOver()
{
    mGameState->SetPaused(true);

    // wait for 10 seconds to finish
    if (mGameState->GetModeTime() < 9 || !mAutomaticQuit)
    {
        return;
    }
    mGameState->Finish();

    if (mGameState->GetModeTime() >= 10)
    {
        std::shared_ptr<GameControlServer> gameControlServer =
            std::dynamic_pointer_cast<GameControlServer>(GetCore()->Get("/sys/server/gamecontrol"));
        gameControlServer->Quit();
    }
}

void
SoccerRuleAspect::CheckTime()
{
    TTime now = mGameState->GetTime();
    TGameHalf half = mGameState->GetGameHalf();

    if ((half == GH_FIRST) && (now >= mHalfTime))
    {
        if (mSingleHalfTime)
        {
            // we want to play only one half of the match
            mGameState->SetPlayMode(PM_GameOver);
        } else {
            // the first game half is over
            mGameState->SetPlayMode(PM_BeforeKickOff);
            mGameState->SetGameHalf(GH_SECOND);
            if (mChangeSidesInSecondHalf)
                SwapTeamSides();
        }
    }
    else if ((half == GH_SECOND) && (now >= 2 * mHalfTime))
    {
        // the game is over
        mGameState->SetPlayMode(PM_GameOver);
    }
}

void SoccerRuleAspect::CheckPenaltyShootoutEnd()
{
    if (mGameState->GetModeTime() <= mDeltaTime * 1.5)
    {
        // The update of the number of shots is delayed by one cycle.
        // Don't check too early; otherwise, a goal might have been awarded
        // and the number of shots would not have been updated accordingly yet.
        // This might be the case when the automatic simple referee punished a team
        // in the preceding cycle with a goal due to the goalie being positioned
        // out of the penalty area.
        // The update would happen in the current cycle in UpdateGoal later on.
        // However, this method is called before UpdateGoal and thus doesn't have the
        // updated value yet.
        return;
    }

    int shots = mGameState->GetPenaltyShootoutShotsExecuted();
    if (shots % 2 != 0)
    {
        // Wait for the other team to make another shot until we decide again if the game is over
        return;
    }

    int rounds = shots / 2;
    if (rounds < mPenaltyShootoutMinRounds)
    {
        // The minimum number of penalty shootout rounds hasn't been played yet.
        return;
    }

    int scoreLeft = mGameState->GetScore(TI_LEFT);
    int scoreRight = mGameState->GetScore(TI_RIGHT);
    if (scoreLeft != scoreRight || rounds >= mPenaltyShootoutMaxRounds)
    {
        // We either have a winner or the maximum number of penalty shootout rounds has been played
        mGameState->SetPlayMode(PM_GameOver);
        return;
    }
}

#ifdef RVDRAW
void 
SoccerRuleAspect::DrawVelocities(TTeamIndex idx)
{
    if (mBallState.get() == 0 || !mRVSender)
        return;
       
    SoccerBase::TAgentStateList agent_states;
    if (!SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    SoccerBase::TAgentStateList::iterator asIt = agent_states.begin();
    for (; asIt != agent_states.end(); ++asIt)
    {
        std::shared_ptr<Transform> transform_parent;
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetTransformParent(*(*asIt), transform_parent);
        SoccerBase::GetAgentBody(transform_parent, agent_body);
        
        // Get agent values
        int uNum = (*asIt)->GetUniformNumber();
        salt::Vector3f agentPos = agent_body->GetPosition();

        // Get average agent velocity
        salt::Vector3f agentAvgVel = salt::Vector3f(0,0,0);
        for(int j = 0; j < AVERAGE_VELOCITY_MEASUREMENTS; j++)
        {
            agentAvgVel.x() = agentAvgVel.x() + playerVelocities[uNum][idx][j].x();
            agentAvgVel.y() = agentAvgVel.y() + playerVelocities[uNum][idx][j].y();
            agentAvgVel.z() = agentAvgVel.z() + playerVelocities[uNum][idx][j].z();
        }

        agentAvgVel.x() = agentAvgVel.x()/AVERAGE_VELOCITY_MEASUREMENTS;
        agentAvgVel.y() = agentAvgVel.y()/AVERAGE_VELOCITY_MEASUREMENTS;
        agentAvgVel.z() = agentAvgVel.z()/AVERAGE_VELOCITY_MEASUREMENTS;

        float speed = sqrt(pow(agentAvgVel.x(), 2) + pow(agentAvgVel.y(), 2));
        
        RVSender::Color c = RVSender::MAGENTA;
        if (speed < mChargingMinSpeed) {
            c = RVSender::GREEN;
        }
        
        if (playerNotStanding[uNum][idx] || playerTimeSinceLastWasMoved[uNum][idx] < 1/.02) {
            c = RVSender::VIOLET;
        }
        
        bool goalieInOwnPenaltyArea = false;
        if (uNum == 1) 
        {
            // Could use playerInsideOwnArea[uNum][idx], however prefer to stretch the area for a goalie behind the goal line
            if (idx == TI_LEFT) {
                if (agentPos.x() <= mLeftPenaltyArea.maxVec[0] && agentPos.y() >= mLeftPenaltyArea.minVec[1] && agentPos.y() <= mLeftPenaltyArea.maxVec[1]) {
                    goalieInOwnPenaltyArea = true;
                }
            } else if (idx == TI_RIGHT) {
                if (agentPos.x() >= mRightPenaltyArea.minVec[0] && agentPos.y() >= mRightPenaltyArea.minVec[1] && agentPos.y() <= mRightPenaltyArea.maxVec[1]) {
                    goalieInOwnPenaltyArea = true;
                }
            }
        }

        bool shade = goalieInOwnPenaltyArea || playerTimeSinceLastBallTouch[uNum][idx] < mChargingImmunityTime/0.02 || playerChargingTime[uNum][idx] < mChargingCollisionMinTime/0.02;
        char buf[512];
        sprintf(buf, "Vel_%s", idx == TI_LEFT ? "Left" : "Right");
        string label = string(buf);
        mRVSender->drawLine(label, agentPos.x(), agentPos.y(), agentPos.x()+agentAvgVel.x(), agentPos.y()+agentAvgVel.y(), c, shade);
    }
}
#endif // RVDRAW

void
SoccerRuleAspect::Update(float deltaTime)
{
    mDeltaTime = deltaTime;
    if (
        (mGameState.get() == 0) ||
        (mBallState.get() == 0) ||
        (mBallBody.get() == 0)
        )
    {
        return;
    }
    mGoalAwarded = false;

    CheckTime();
    if (mPenaltyShootout)
    {
        CheckPenaltyShootoutEnd();
    }

    TPlayMode playMode = mGameState->GetPlayMode();

    static bool updated = false;

    mLastModeWasPlayOn = false;

    if (!mAllowKickOffTeamToScore) {
        // Check if requirements/rules have been met for team taking kickoff 
        // to score
        std::shared_ptr<AgentState> agentState;
        if (!SoccerBase::GetAgentState(mLastKickOffTaker, agentState))
            {
                GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot"
                    " get AgentState from an AgentAspect\n";
            }
        else {
            TTeamIndex team = agentState->GetTeamIndex();
            bool ballTouchedByKickOffTeam = 
                mBallState->GetBallCollidingWithAgentTeam(team);
            bool ballTouchedByNonKickOffTeam = 
                mBallState->GetBallCollidingWithAgentTeam(SoccerBase::OpponentTeam(team));
            salt::Vector2f ball_pos(mBallBody->GetPosition().x(), mBallBody->GetPosition().y());
            bool ballOutsideCenterCircle = ball_pos.Length() > mFreeKickDist;
            mAllowKickOffTeamToScore = ballTouchedByNonKickOffTeam ||
                (ballTouchedByKickOffTeam && ballOutsideCenterCircle);
        }
    }

    switch (playMode)
    {
    case PM_BeforeKickOff:
        // At the beginning of the match, we update the member variables
        // with the values from the ruby script (once). At this point in time,
        // the ruby script has definitely been processed.
        if (! updated)
        {
            UpdateCachedInternal();
            if (mWriteSelfCollisionsToFile) {
                selfCollisionsFile.open(mSelfCollisionRecordFilename, std::ios_base::app);
            }
            updated = true;
        }
        // Below is the check we do during before kick off mode.
        UpdateBeforeKickOff();
        break;

    case PM_PlayOn:
        UpdatePlayOn();
        // [patmac] mLastModeWasPlayOn is currently only used in CheckOffside() and will always be false when referenced in CheckOffside() -- should probably be removed
        mLastModeWasPlayOn = true;  
        break;

    case PM_KickOff_Left:
        UpdateKickOff(TI_LEFT);
        break;
    case PM_KickOff_Right:
        UpdateKickOff(TI_RIGHT);
        break;

    case PM_FREE_KICK_LEFT:
        UpdateFreeKick(TI_LEFT, true);
        break;
    case PM_FREE_KICK_RIGHT:
        UpdateFreeKick(TI_RIGHT, true);
        break;

    case PM_DIRECT_FREE_KICK_LEFT:
        UpdateFreeKick(TI_LEFT, false);
        break;
    case PM_DIRECT_FREE_KICK_RIGHT:
        UpdateFreeKick(TI_RIGHT, false);
        break;

    case PM_KickIn_Left:
        UpdateKickIn(TI_LEFT);
        break;
    case PM_KickIn_Right:
        UpdateKickIn(TI_RIGHT);
        break;

    case PM_GOAL_KICK_LEFT:
        UpdateGoalKick(TI_LEFT);
        break;
    case PM_GOAL_KICK_RIGHT:
        UpdateGoalKick(TI_RIGHT);
        break;

    case PM_CORNER_KICK_LEFT:
        UpdateCornerKick(TI_LEFT);
        break;
    case PM_CORNER_KICK_RIGHT:
        UpdateCornerKick(TI_RIGHT);
        break;

    case PM_PASS_LEFT:
        UpdatePassMode(TI_LEFT);
        break;
    case PM_PASS_RIGHT:
        UpdatePassMode(TI_RIGHT);
        break;
        
    case PM_Goal_Left:
        if (!mPenaltyShootout)
        {
            ClearPlayersBeforeKickOff(TI_RIGHT);
        }
        else
        {
            ClearPlayersDuringPenaltyShootout();
        }
        
        UpdateGoal();
        break;
    case PM_Goal_Right:
        if (!mPenaltyShootout)
        {
            ClearPlayersBeforeKickOff(TI_LEFT);
        }
        else
        {
            ClearPlayersDuringPenaltyShootout();
        }
        UpdateGoal();
        break;

    case PM_OFFSIDE_LEFT:
        UpdateOffside(TI_LEFT);
        break;
    case PM_OFFSIDE_RIGHT:
        UpdateOffside(TI_RIGHT);
        break;

    case PM_GameOver:
        UpdateGameOver();
        break;

    default:
        GetLog()->Error()
            << "ERROR: (SoccerRuleAspect) unknown play mode "
            << playMode << "\n";
        break;
    }

    //Get velocity to calculate averages
    SoccerBase::TAgentStateList agent_states;
    if (!SoccerBase::GetAgentStates(*mBallState.get(), agent_states))
        return;
    
    SoccerBase::TAgentStateList::iterator asIt = agent_states.begin();
    for (; asIt != agent_states.end(); ++asIt)
    {
        std::shared_ptr<Transform> transform_parent;
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetTransformParent(*(*asIt), transform_parent);
        SoccerBase::GetAgentBody(transform_parent, agent_body);
        int unum;
        int idx;
        unum = (*asIt)->GetUniformNumber();
        idx = (*asIt)->GetTeamIndex();
        
        for(int i = AVERAGE_VELOCITY_MEASUREMENTS-1; i > 0; i--)
        {
            playerVelocities[unum][idx][i] = playerVelocities[unum][idx][i-1];
        }

        playerVelocities[unum][idx][0] = agent_body->GetVelocity();
            
    }
     
#ifdef RVDRAW
    if (mRVSender) {
        mRVSender->clear();
        DrawVelocities(TI_LEFT);
        DrawVelocities(TI_RIGHT);
        mRVSender->refresh();
    }
#endif // RVDRAW

    // Simple Referee
    AutomaticSimpleReferee();
}

void
SoccerRuleAspect::OnLink()
{
    SoccerControlAspect::OnLink();

    GetControlAspect(mGameState, "GameStateAspect");

    if (mGameState.expired())
        {
            GetLog()->Error()
                    << "(SoccerRuleAspect) ERROR: could not get GameStateAspect\n";
        }

    GetControlAspect(mBallState, "BallStateAspect");

    if (mBallState.expired())
        {
            GetLog()->Error()
                    << "(SoccerRuleAspect) ERROR: could not get BallStateAspect\n";
        }

    SoccerBase::GetBallBody(*this,mBallBody);
}

void
SoccerRuleAspect::OnUnlink()
{
    SoccerControlAspect::OnUnlink();

    mGameState.reset();
    mBallState.reset();
    mBallBody.reset();
}

void
SoccerRuleAspect::UpdateCachedInternal()
{
    SoccerBase::GetSoccerVar(*this,"BallRadius",mBallRadius);
    SoccerBase::GetSoccerVar(*this,"AgentRadius",mAgentRadius);
    SoccerBase::GetSoccerVar(*this,"RuleGoalPauseTime",mGoalPauseTime);
    SoccerBase::GetSoccerVar(*this,"RuleKickInPauseTime",mKickInPauseTime);
    SoccerBase::GetSoccerVar(*this,"RuleHalfTime",mHalfTime);
    SoccerBase::GetSoccerVar(*this,"RuleDropBallTime",mDropBallTime);
    SoccerBase::GetSoccerVar(*this,"FieldLength",mFieldLength);
    SoccerBase::GetSoccerVar(*this,"FieldWidth",mFieldWidth);
    SoccerBase::GetSoccerVar(*this,"GoalWidth",mGoalWidth);
    SoccerBase::GetSoccerVar(*this,"GoalHeight",mGoalHeight);
    SoccerBase::GetSoccerVar(*this,"FreeKickDistance",mFreeKickDist);
    SoccerBase::GetSoccerVar(*this,"FreeKickMoveDist",mFreeKickMoveDist);
    SoccerBase::GetSoccerVar(*this,"KickRepelDist",mKickRepelDist);
    SoccerBase::GetSoccerVar(*this,"GoalKickDist",mGoalKickDist);
    SoccerBase::GetSoccerVar(*this,"AutomaticKickOff",mAutomaticKickOff);
    SoccerBase::GetSoccerVar(*this,"WaitBeforeKickOff",mWaitBeforeKickOff);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootout",mPenaltyShootout);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootoutBallDistance",mPenaltyShootoutBallDistance);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootoutBehindBallDistance",mPenaltyShootoutBehindBallDistance);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootoutMaxTime",mPenaltyShootoutMaxTime);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootoutMinRounds",mPenaltyShootoutMinRounds);
    SoccerBase::GetSoccerVar(*this,"PenaltyShootoutMaxRounds",mPenaltyShootoutMaxRounds);
    SoccerBase::GetSoccerVar(*this,"SingleHalfTime",mSingleHalfTime);
    SoccerBase::GetSoccerVar(*this,"AutomaticQuit",mAutomaticQuit);
    SoccerBase::GetSoccerVar(*this,"ChangeSidesInSecondHalf",mChangeSidesInSecondHalf);
    SoccerBase::GetSoccerVar(*this,"UseOffside",mUseOffside);
    float penaltyLength, penaltyWidth;
    SoccerBase::GetSoccerVar(*this,"PenaltyLength",penaltyLength);
    SoccerBase::GetSoccerVar(*this,"PenaltyWidth",penaltyWidth);

    // keepaway mode parameters
    SoccerBase::GetSoccerVar(*this,"Keepaway",mKeepaway);
    SoccerBase::GetSoccerVar(*this,"KeepawayCenterX",mKeepawayCenterX);
    SoccerBase::GetSoccerVar(*this,"KeepawayCenterY",mKeepawayCenterY);
    SoccerBase::GetSoccerVar(*this,"KeepawayLength",mKeepawayLength);
    SoccerBase::GetSoccerVar(*this,"KeepawayWidth",mKeepawayWidth);
    SoccerBase::GetSoccerVar(*this,"KeepawayLengthReductionRate",mKeepawayLengthReductionRate);
    SoccerBase::GetSoccerVar(*this,"KeepawayWidthReductionRate",mKeepawayWidthReductionRate);

    // auto ref parameters
    SoccerBase::GetSoccerVar(*this,"NotStandingMaxTime",mNotStandingMaxTime);
    SoccerBase::GetSoccerVar(*this,"GoalieNotStandingMaxTime",mGoalieNotStandingMaxTime);
    SoccerBase::GetSoccerVar(*this,"GroundMaxTime",mGroundMaxTime);
    SoccerBase::GetSoccerVar(*this,"GoalieGroundMaxTime",mGoalieGroundMaxTime);
    SoccerBase::GetSoccerVar(*this,"MaxPlayersInsideOwnArea",mMaxPlayersInsideOwnArea);
    SoccerBase::GetSoccerVar(*this,"IllegalDefenseBeamPenalty",mIllegalDefenseBeamPenalty);
    SoccerBase::GetSoccerVar(*this,"MinOppDistance",mMinOppDistance);
    SoccerBase::GetSoccerVar(*this,"Min2PlDistance",mMin2PlDistance);
    SoccerBase::GetSoccerVar(*this,"Min3PlDistance",mMin3PlDistance);
    SoccerBase::GetSoccerVar(*this,"MaxTouchGroupSize",mMaxTouchGroupSize);
    SoccerBase::GetSoccerVar(*this,"TouchingFoulBeamPenalty",mTouchingFoulBeamPenalty);
    //SoccerBase::GetSoccerVar(*this,"MaxFoulTime",mMaxFoulTime);
    SoccerBase::GetSoccerVar(*this,"UseCharging",mUseCharging);
    SoccerBase::GetSoccerVar(*this,"ChargingMinSpeed",mChargingMinSpeed);
    SoccerBase::GetSoccerVar(*this,"ChargingMinBallSpeedAngle",mChargingMinBallSpeedAngle);
    SoccerBase::GetSoccerVar(*this,"ChargingMinDeltaDist",mChargingMinDeltaDist);
    SoccerBase::GetSoccerVar(*this,"ChargingMinDeltaAng",mChargingMinDeltaAng);
    SoccerBase::GetSoccerVar(*this,"ChargingImmunityTime",mChargingImmunityTime);
    SoccerBase::GetSoccerVar(*this,"ChargingCollisionMinTime",mChargingCollisionMinTime);
    SoccerBase::GetSoccerVar(*this,"ChargingMaxBallRulesDist",mChargingMaxBallRulesDist);
    SoccerBase::GetSoccerVar(*this,"ChargingMinCollBallDist",mChargingMinCollBallDist);
    SoccerBase::GetSoccerVar(*this,"ChargingMinCollisionSpeed",mMinCollisionSpeed);
    SoccerBase::GetSoccerVar(*this,"FoulHoldTime",mFoulHoldTime);

    SoccerBase::GetSoccerVar(*this,"BallHoldRadius",mBallHoldRadius);
    SoccerBase::GetSoccerVar(*this,"BallHoldMaxTime",mBallHoldMaxTime);
    SoccerBase::GetSoccerVar(*this,"BallHoldGoalieMaxTime",mBallHoldGoalieMaxTime);
    SoccerBase::GetSoccerVar(*this,"BallHoldResetTime",mBallHoldResetTime);
    SoccerBase::GetSoccerVar(*this,"BallHoldMaxDistance",mBallHoldMaxDistance);
    SoccerBase::GetSoccerVar(*this,"BallHoldOppDistance",mBallHoldOppDistance);
    SoccerBase::GetSoccerVar(*this,"BallHoldBeamPenalty",mBallHoldBeamPenalty);

    SoccerBase::GetSoccerVar(*this,"SelfCollisionsTolerance",mSelfCollisionsTolerance);
    SoccerBase::GetSoccerVar(*this,"PrintSelfCollisions",mPrintSelfCollisions);
    SoccerBase::GetSoccerVar(*this,"FoulOnSelfCollisions",mFoulOnSelfCollisions);
    SoccerBase::GetSoccerVar(*this,"SelfCollisionJointFrozenTime",mSelfCollisionJointFrozenTime);
    SoccerBase::GetSoccerVar(*this,"SelfCollisionJointThawTime",mSelfCollisionJointThawTime);
    SoccerBase::GetSoccerVar(*this,"SelfCollisionBeamPenalty",mSelfCollisionBeamPenalty);
    SoccerBase::GetSoccerVar(*this,"SelfCollisionBeamCooldownTime",mSelfCollisionBeamCooldownTime);
    SoccerBase::GetSoccerVar(*this,"WriteSelfCollisionsToFile",mWriteSelfCollisionsToFile);
    SoccerBase::GetSoccerVar(*this,"SelfCollisionRecordFilename",mSelfCollisionRecordFilename);

    SoccerBase::GetSoccerVar(*this,"MaxNumSafeRepositionAttempts",mMaxNumSafeRepositionAttempts);
    SoccerBase::GetSoccerVar(*this,"StartAnyFieldPosition",mStartAnyFieldPosition);
    SoccerBase::GetSoccerVar(*this,"PassModeMaxBallSpeed",mPassModeMaxBallSpeed);
    SoccerBase::GetSoccerVar(*this,"PassModeMaxBallDist",mPassModeMaxBallDist);
    SoccerBase::GetSoccerVar(*this,"PassModeMinOppBallDist",mPassModeMinOppBallDist);
    SoccerBase::GetSoccerVar(*this,"PassModeDuration",mPassModeDuration);
    SoccerBase::GetSoccerVar(*this,"PassModeScoreWaitTime",mPassModeScoreWaitTime);
    SoccerBase::GetSoccerVar(*this,"PassModeRetryWaitTime",mPassModeRetryWaitTime);


    // cout << "MaxInside " << mMaxPlayersInsideOwnArea << endl << endl;
    // set up bounding boxes for halfs and goal areas

    // the right and the left half are intentionally oversized towards the sides and
    // the end of the field so that no opponents sneak up from behind.
    mRightHalf = salt::AABB2(Vector2f(0, -mFieldWidth/2.0 - 10.0),
                             Vector2f(mFieldLength/2.0 + 10, mFieldWidth/2.0 + 10.0));
    mLeftHalf = salt::AABB2(Vector2f(0, -mFieldWidth/2.0 - 10.0),
                            Vector2f(-mFieldLength/2.0 - 10, mFieldWidth/2.0 + 10.0));

    // the penalty areas (exact sizes)
    mRightPenaltyArea = salt::AABB2(Vector2f(mFieldLength/2.0 - penaltyLength,
                                             -(penaltyWidth + mGoalWidth)/2.0),
                                    Vector2f(mFieldLength/2.0,
                                             (penaltyWidth + mGoalWidth)/2.0));
    mLeftPenaltyArea = salt::AABB2(Vector2f(-mFieldLength/2.0 + penaltyLength,
                                            -(penaltyWidth + mGoalWidth)/2.0),
                                   Vector2f(-mFieldLength/2.0,
                                            (penaltyWidth + mGoalWidth)/2.0));

    mGoalBallLineX = mFieldLength / 2.0 + mBallRadius;

    if (mPenaltyShootout)
    {
        // Overwrite mSingleHalfTime
        // Two half times don't make sense with the current implementation
        // of the penalty shootout
        mSingleHalfTime = true;
        // Calculate the length for the single half time
        mHalfTime = 2.0 * mPenaltyShootoutMaxRounds * (mPenaltyShootoutMaxTime + mGoalPauseTime);
        mHalfTime += 1.0; // Add one second of tolerance, just to be sure we're not stopping too early
    }
}

void
SoccerRuleAspect::Broadcast(const string& message, const Vector3f& pos,
                            int number, TTeamIndex idx)
{
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
    {
        return;
    }

    SoccerBase::TAgentStateList opponent_agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), opponent_agent_states,
                                     SoccerBase::OpponentTeam(idx)))
    {
        return;
    }

    if (static_cast<int>(message.size()) > mSayMsgSize)
    {
        return;
    }

    salt::BoundingSphere sphere(pos, mAudioCutDist);

    std::shared_ptr<Transform> transform_parent;
    std::shared_ptr<RigidBody> agent_body;

    std::string team = "";

    for (
        SoccerBase::TAgentStateList::const_iterator it = agent_states.begin();
        it != agent_states.end();
        it++
        )
    {
        // Get name of team to label all messages with
        team = (*it)->GetPerceptName(ObjectState::PT_Player);
        if ( (*it)->GetUniformNumber() == number)
        {
            (*it)->AddSelfMessage(message);
            continue;
        }
        SoccerBase::GetTransformParent(*(*it), transform_parent);

        // call GetAgentBody with matching AgentAspect
        SoccerBase::GetAgentBody(transform_parent, agent_body);

        // if the player is in the range, send the message
        Vector3f new_pos = agent_body->GetPosition();
        if (sphere.Contains(new_pos))
        {
            Vector3f relPos = pos - new_pos;
            relPos = SoccerBase::FlipView(relPos, idx);
            float direction = salt::gRadToDeg(salt::gArcTan2(relPos[1], relPos[0]));
            (*it)->AddMessage(message, team, direction, true);
        }
    }

    for (
        SoccerBase::TAgentStateList::const_iterator it = opponent_agent_states.begin();
        it != opponent_agent_states.end();
        it++
        )
    {
        SoccerBase::GetTransformParent(*(*it), transform_parent);

        // call GetAgentBody with matching AgentAspect
        SoccerBase::GetAgentBody(transform_parent, agent_body);

        // if the player is in the range, send the message
        Vector3f new_pos = agent_body->GetPosition();
        if (sphere.Contains(new_pos))
        {
            Vector3f relPos = pos - new_pos;
            relPos = SoccerBase::FlipView(relPos, SoccerBase::OpponentTeam(idx));
            float direction = salt::gRadToDeg(salt::gArcTan2(relPos[1], relPos[0]));
            (*it)->AddMessage(message, team, direction, false);
        }
    }
}

bool
SoccerRuleAspect::CheckOffside()
{
    return true;

#if 0
    std::shared_ptr<AgentAspect> collidingAgent;
    std::shared_ptr<AgentAspect> kickingAgent;
    std::shared_ptr<AgentAspect> agent;
    std::shared_ptr<AgentState> agentState;
    TTime collidingTime;
    TTime kickingTime;
    TTime time;
    static TTime lastCollisionTime = 0.0;

    if (! mLastModeWasPlayOn)
    {
        mInOffsideLeftPlayers.clear();
        mInOffsideRightPlayers.clear();
    }

    if (! mBallState->GetLastCollidingAgent(collidingAgent,collidingTime) )
    {
        return false;
    }

    if (! mBallState->GetLastKickingAgent(kickingAgent,kickingTime) )
    {
        return false;
    }

    if (collidingTime > kickingTime)
    {
        time = collidingTime;
        agent = collidingAgent;
    }
    else
    {
        time = kickingTime;
        agent = kickingAgent;
    }

    // if the last colliding agent is the first agent that touches the ball
    // after "a goal kick" or "a kick-in(FIFA: throw-in)" or "a corner kick"
    TTime lastModeChange = mGameState->GetLastModeChange();

    if (time == lastModeChange)
    {
        mFirstCollidingAgent = true;
    }

    // only when an agent collides with the ball it maybe affect
    // offside, if we sometime want to consider
    // "interfering with an opponent" we should remove this condition
    if (lastCollisionTime == time)
    {
        return false;
    }
    lastCollisionTime = time;

    // if the second last collinding agent is the last colliding agent,
    // there is no offside
    if (mPreLastCollidingAgent == agent)
    {
        mNotOffside = true;
    }
    else
    {
        mPreLastCollidingAgent = agent;
        mNotOffside = false;
    }

    // find the positions of the last opponent defender and the second last one
    if (! SoccerBase::GetAgentState(agent,agentState))
    {
        return false;
    }

    TTeamIndex idx = agentState->GetTeamIndex();

    list<std::shared_ptr<AgentState> > opp_agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState, opp_agent_states,
          SoccerBase::OpponentTeam(idx)))
    {
        return false;
    }

    float opp_goalkeeper_pos;
    float opp_defender_pos;

    opp_goalkeeper_pos = 0.0;
    opp_defender_pos   = 0.0;

    std::shared_ptr<Transform> transform_parent;
    std::shared_ptr<RigidBody> agent_body;

    list<std::shared_ptr<AgentState> >::const_iterator it;
    for (it = opp_agent_states.begin(); it != opp_agent_states.end(); it++)
    {
        SoccerBase::GetTransformParent(*(*it), transform_parent);
        SoccerBase::GetAgentBody(transform_parent, agent_body);

        Vector3f opp_agent_pos = agent_body->GetPosition();

        if (SoccerBase::OpponentTeam(idx) == TI_LEFT)
        {
            if (opp_agent_pos[0] <= opp_goalkeeper_pos)
            {
                opp_defender_pos   = opp_goalkeeper_pos;
                opp_goalkeeper_pos = opp_agent_pos[0];
            }
            else if (opp_agent_pos[0] <= opp_defender_pos)
            {
                opp_defender_pos = opp_agent_pos[0];
            }
        }
        else
        {
            if (opp_agent_pos[0] >= opp_goalkeeper_pos)
            {
                opp_defender_pos   = opp_goalkeeper_pos;
                opp_goalkeeper_pos = opp_agent_pos[0];
            }
            else if (opp_agent_pos[0] >= opp_defender_pos)
            {
                opp_defender_pos = opp_agent_pos[0];
            }
        }
    }

    Vector3f ball_pos = mBallBody->GetPosition();

    SoccerBase::GetTransformParent(*agentState, transform_parent);
    SoccerBase::GetAgentBody(transform_parent, agent_body);
    Vector3f agent_pos = agent_body->GetPosition();

    if ( mFirstCollidingAgent )
    {
        if (((idx == TI_LEFT) && (agent_pos[0] > opp_defender_pos)
                && (agent_pos[0] > ball_pos[0])) ||
            ((idx == TI_RIGHT) && (agent_pos[0] < opp_defender_pos)
                && (agent_pos[0] < ball_pos[0])))
        {
            mFirstCollidingAgent = true;
        }
        else
        {
            mFirstCollidingAgent = false;
        }
    }

    // if the agent,that touches the ball was in
    // offside position before the last shoot, change the mode to offside
    bool offside = false;

    if ((idx == TI_LEFT) && !mFirstCollidingAgent && !mNotOffside)
    {
        vector<int>::const_iterator it_offside;
        for (
            it_offside = mInOffsideLeftPlayers.begin();
            it_offside != mInOffsideLeftPlayers.end();
            it_offside++)
        {
            if (agentState->GetUniformNumber() == *it_offside)
            {
                mGameState->SetPlayMode(PM_OFFSIDE_RIGHT);
                offside = true;
            }
        }
        if (!offside && (agent_pos[0] > opp_defender_pos))
            mFirstCollidingAgent = true;
    }
    else if (!mFirstCollidingAgent && !mNotOffside)
    {
        vector<int>::const_iterator it_offside;
        for (
            it_offside = mInOffsideRightPlayers.begin();
            it_offside != mInOffsideRightPlayers.end();
            it_offside++
            )
        {
            if (agentState->GetUniformNumber() == *it_offside)
            {
                mGameState->SetPlayMode(PM_OFFSIDE_LEFT);
                offside = true;
            }
        }
        if (!offside && (agent_pos[0] < opp_defender_pos))
            mFirstCollidingAgent = true;
    }

    // update the list of players that are in offside poistion
    mInOffsideLeftPlayers.clear();
    mInOffsideRightPlayers.clear();

    mFreeKickPos = mBallState->GetLastValidBallPosition();
    mFreeKickPos[2] = mBallRadius;

    list<std::shared_ptr<AgentState> > agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState, agent_states, idx))
    {
        return false;
    }

    for (it = agent_states.begin(); it != agent_states.end(); it++)
    {
        SoccerBase::GetTransformParent(*(*it), transform_parent);
        SoccerBase::GetAgentBody(transform_parent, agent_body);

        Vector3f agent_pos = agent_body->GetPosition();

        if (idx == TI_LEFT)
        {
            if ((agent_pos[0] > opp_defender_pos)
                 && (agent_pos[0] > ball_pos[0]))
            {
                mInOffsideLeftPlayers.push_back((*it)->GetUniformNumber());
            }
        }
        else
        {
            if ((agent_pos[0] < opp_defender_pos)
                 && (agent_pos[0] < ball_pos[0]))
            {
                mInOffsideRightPlayers.push_back((*it)->GetUniformNumber());
            }
        }
    }

    return true;
#endif
}

void
SoccerRuleAspect::UpdateOffside(TTeamIndex idx)
{
#if 0
    // do nothing for the duration of mKickInPauseTime
    if (mGameState->GetModeTime() < mKickInPauseTime)
    {
        mRepelPlayersForKick = true;
        return;
    }

    ResetKickChecks();

    // move away opponent team
    Vector3f ball_pos = mBallBody->GetPosition();
    ClearPlayers(mFreeKickPos, mFreeKickDist, mFreeKickMoveDist,
                 SoccerBase::OpponentTeam(idx));

    // if no player touched the ball for mDropBallTime, we move away
    // all players and set the play mode to play on
    if (mDropBallTime > 0 &&
        mGameState->GetModeTime() > mDropBallTime)
    {
        DropBall(mFreeKickPos);
        return;
    }

    // after the first agent touches the ball move to PM_PLAY_ON. the
    // time when the agent last touches the ball must be after the
    // change to the OffsideKick mode
    std::shared_ptr<AgentAspect> agent;
    std::shared_ptr<AgentState> agentState;
    TTime time;
    if (! mBallState->GetLastCollidingAgent(agent,time))
    {
        GetLog()->Error()
            << "ERROR: (SoccerRuleAspect) no agent collided yet\n";
        return;
    }

    if (! SoccerBase::GetAgentState(agent,agentState))
    {
        return;
    }

    TTeamIndex collidingAgentIdx = agentState->GetTeamIndex();

    TTime lastChange = mGameState->GetLastModeChange();
    if (time > lastChange + 0.03 && collidingAgentIdx==idx && !mRepelPlayersForKick)
    {
        mGameState->SetPlayMode(PM_PlayOn);
    }
    else
    {
        RepelPlayersForKick(idx);
        
        // move the ball back on the free kick position
        MoveBall(mFreeKickPos);
    }
#endif
}

void
SoccerRuleAspect::ClearPlayersWithException(const salt::Vector3f& pos,
                               float radius, float min_dist, TTeamIndex idx,
                               std::shared_ptr<AgentState> agentState)
{
    if (idx == TI_NONE || mBallState.get() == 0) return;
    SoccerBase::TAgentStateList agent_states;
    if (! SoccerBase::GetAgentStates(*mBallState.get(), agent_states, idx))
        return;

    shuffle(agent_states.begin(), agent_states.end(), mRng);

    salt::BoundingSphere sphere(pos, radius);
    std::shared_ptr<oxygen::Transform> agent_aspect;
    SoccerBase::TAgentStateList::const_iterator i;
    for (i = agent_states.begin(); i != agent_states.end(); ++i)
    {
        if (agentState == (*i))
            continue;

        SoccerBase::GetTransformParent(**i, agent_aspect);
        std::shared_ptr<RigidBody> agent_body;
        SoccerBase::GetAgentBody(agent_aspect, agent_body);
        Vector3f moved_adjustment = agent_body->GetPosition() - agent_aspect->GetWorldTransform().Pos();
        AABB3 agentAABB = SoccerBase::GetAgentBoundingBox(*agent_aspect);
        agentAABB.Translate(moved_adjustment);
        
        // if agent is too close, move it away
        Vector3f new_pos = agent_body->GetPosition();
        if (sphere.Intersects(agentAABB))
        {
            float dist = min_dist; //salt::UniformRNG<>(min_dist, min_dist + 2.0)();

            if (idx == TI_LEFT)
            {
                if (pos[0] - dist < -mFieldLength/2.0)
                {
                    new_pos[1] = pos[1] < 0 ? pos[1] + dist : pos[1] - dist;
                } else {
                    new_pos[0] = pos[0] - dist;
                }
            } else {
                if (pos[0] + dist > mFieldLength/2.0)
                {
                    new_pos[1] = pos[1] < 0 ? pos[1] + dist : pos[1] - dist;
                } else {
                    new_pos[0] = pos[0] + dist;
                }
            }
            MoveAgent(agent_aspect, new_pos);
        }
    }
}

Vector2f
SoccerRuleAspect::GetFieldSize() const
{
    return Vector2f(mFieldLength,mFieldWidth);
}

salt::AABB2
SoccerRuleAspect::GetLeftPenaltyArea() const
{
    return mLeftPenaltyArea;
}

salt::AABB2
SoccerRuleAspect::GetRightPenaltyArea() const
{
    return mRightPenaltyArea;
}

void
SoccerRuleAspect::ResetAgentSelection()
{
    SoccerBase::TAgentStateList agent_states;
    if (SoccerBase::GetAgentStates(*mBallState.get(), agent_states, TI_NONE))
    {

        SoccerBase::TAgentStateList::const_iterator i;
        for (i = agent_states.begin(); i != agent_states.end(); ++i)
          (*i)->UnSelect();
    }
}

void
SoccerRuleAspect::SelectNextAgent()
{
    SoccerBase::TAgentStateList agent_states;
    bool selectNext = false;
    if (SoccerBase::GetAgentStates(*mBallState.get(), agent_states, TI_NONE) && agent_states.size() > 0)
    {
        std::shared_ptr<AgentState> first = agent_states.front();

        SoccerBase::TAgentStateList::const_iterator i;
        for (i = agent_states.begin(); i != agent_states.end(); ++i)
        {
            if ((*i)->IsSelected())
            {
                (*i)->UnSelect();
                selectNext = true;
                continue;
            }
            else if (selectNext)
            {
              (*i)->Select();
              return;
            }
        }

        // No agent selected, select first
        first->Select();
    }
}


bool
SoccerRuleAspect::MoveAgent(std::shared_ptr<Transform> agent_aspect, const Vector3f& pos, bool fSafe, bool fAvoidBall)
{
    Vector3f move_pos = pos;

    std::shared_ptr<AgentState> agentState;
    if (!SoccerBase::GetAgentState(agent_aspect, agentState))
    {
        GetLog()->Error() << "ERROR: (SoccerRuleAspect) Cannot get "
            "AgentState from an AgentAspect\n";
    }
    else
    {
        int unum = agentState->GetUniformNumber();
        TTeamIndex idx = agentState->GetTeamIndex();
        playerTimeSinceLastWasMoved[unum][idx] = 0; 
        
        if (fSafe) {
            move_pos = GetSafeReposition(pos, unum, idx, fAvoidBall);
        }
    }

    return SoccerBase::MoveAgent(agent_aspect, move_pos);
}

bool
SoccerRuleAspect::HaveEnforceableFoul(int unum, TTeamIndex ti)
{
    return playerLastFoul[unum][ti] != FT_None
        && (playerFoulTime[unum][ti] > mMaxFoulTime / 0.02
            || playerLastFoul[unum][ti] == FT_Charging
            || playerLastFoul[unum][ti] == FT_Touching
            || playerLastFoul[unum][ti] == FT_SelfCollision);
}

bool
SoccerRuleAspect::CanActivatePassMode(int unum, TTeamIndex ti)
{
    // Only allow when in PlayOn (in a regular game)
    if (mGameState->GetPlayMode() != PM_PlayOn || mPenaltyShootout) {
        return false;
    }


    // Can't activate pass mode if it was recently used
    if (mGameState->GetTime() - mGameState->GetLastTimeInPassMode(ti) < mPassModeRetryWaitTime) {
        return false;
    }


    // If a player from the team is currently touching the ball don't activate 
    if (mBallState->GetBallCollidingWithAgentTeam(ti)) {
        return false;
    }


    // Can't acticate when then ball is moving too much
    salt::Vector3f ballVel = mBallBody->GetVelocity();
    float ballSpeed = sqrt(pow(ballVel.x(),2)+pow(ballVel.y(),2)+pow(ballVel.z(),2));
    if (ballSpeed > mPassModeMaxBallSpeed) {
        return false;
    }


    // Can only activate if the agent is close to the ball
    // Check original/current distance
    if (distArr[unum][ti] > mPassModeMaxBallDist) {
        return false;
    }

    salt::Vector3f ballPos = mBallBody->GetPosition();
    std::shared_ptr<AgentState> agent_state; 
    if (!SoccerBase::GetAgentState(*mBallState.get(), ti, unum, agent_state)) {
        return false;
    }

    std::shared_ptr<Transform> transform_parent;
    std::shared_ptr<RigidBody> agent_body;
    SoccerBase::GetTransformParent(*agent_state, transform_parent);
    SoccerBase::GetAgentBody(transform_parent, agent_body);
    salt::Vector3f agentPos = agent_body->GetPosition();

    float ballDist = sqrt((agentPos.x()-ballPos.x())*(agentPos.x()-ballPos.x()) +
                          (agentPos.y()-ballPos.y())*(agentPos.y()-ballPos.y()));
    
    // Check updated distance if player or ball is being moved this cycle
    if (ballDist > mPassModeMaxBallDist) {
        return false;
    }


    // Check that no opponents are too close to the ball before activating
    for(int i = 1; i <= 11; i++) {
        // Check original/current distance
        if (distArr[i][SoccerBase::OpponentTeam(ti)] < mPassModeMinOppBallDist) {
            return false;
        }
    }

    SoccerBase::TAgentStateList agent_states;
    if (SoccerBase::GetAgentStates(*mBallState.get(), agent_states, SoccerBase::OpponentTeam(ti))) {
        std::shared_ptr<oxygen::Transform> agent_aspect;
        SoccerBase::TAgentStateList::const_iterator i;

        for (i = agent_states.begin(); i != agent_states.end(); ++i)
        {
            SoccerBase::GetTransformParent(**i, transform_parent);
            SoccerBase::GetAgentBody(transform_parent, agent_body);
            agentPos = agent_body->GetPosition();
            ballDist = sqrt((agentPos.x()-ballPos.x())*(agentPos.x()-ballPos.x()) +
                            (agentPos.y()-ballPos.y())*(agentPos.y()-ballPos.y()));
            // Check updated distance if player or ball is being moved this cycle
            if (ballDist < mPassModeMinOppBallDist) {
                return false;
            }
        }
    } 

    return true;
}
