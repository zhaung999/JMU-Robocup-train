/* -*- mode: c++; c-basic-offset: 4; indent-tabs-mode: nil -*-

   this file is part of rcssserver3D
   Fri May 9 2003
   Copyright (C) 2002,2003 Koblenz University
   Copyright (C) 2003 RoboCup Soccer Server 3D Maintenance Group
   $Id$

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifndef PASSEFFECTOR_H
#define PASSEFFECTOR_H

#include <oxygen/agentaspect/effector.h>
//#include <gamestateaspect/gamestateaspect.h>

class GameStateAspect;
class AgentState;
class SoccerRuleAspect;

class PassEffector : public oxygen::Effector
{
public:
    PassEffector();
    virtual ~PassEffector();

    /** returns the name of the predicate this effector implements. */
    virtual std::string GetPredicate() { return "pass"; }

    /** constructs an Actionobject, describing a predicate */
    virtual std::shared_ptr<oxygen::ActionObject>
    GetActionObject(const oxygen::Predicate& predicate);

protected:
    /** setup the reference to the agents body node */
    virtual void OnLink();

    /** remove the reference to the agents body node */
    virtual void OnUnlink();

    /** realizes the action described by the ActionObject */
    virtual void PrePhysicsUpdateInternal(float deltaTime);

protected:
    /** the reference to the GameState */
    std::shared_ptr<GameStateAspect> mGameState;

    /** a reference to the agent state */
    std::shared_ptr<AgentState> mAgentState;

    /** reference to the soccer rule aspect */
    std::shared_ptr<SoccerRuleAspect> mSoccerRule;
};

DECLARE_CLASS(PassEffector)

#endif // PASSEFFECTOR_H
