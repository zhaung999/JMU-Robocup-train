/** this is a static (i.e. not auto generated) win32 specific
    configuration file
*/
#define HAVE_KEROSIN_KEROSIN_H 1

#define PACKAGE_NAME "rcssserver3d"
#define RCSS_BUNDLE_PATH "."

#define HAVE_WINSOCK2_H 1
#define HAVE_SOCKET 1
#define HAVE_SOCKETTYPE 1
