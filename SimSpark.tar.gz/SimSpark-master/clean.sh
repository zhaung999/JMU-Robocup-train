rm -rf spark/build
rm -rf rcssserver3d/build

